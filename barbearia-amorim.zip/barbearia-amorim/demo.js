'use strict';
// Popula um banco de DEMONSTRAÇÃO (barbeiros fictícios, atendimentos e faturamento dos últimos meses).
// Uso:  DATA_DIR=./data-demo node demo.js   &&   DATA_DIR=./data-demo node server.js
// Login do proprietário na demo: admin / admin12345   |  barbeiros: carlos, rafael, diego / demo12345
const path = require('node:path');
const DB = require('./db');

const dataDir = process.env.DATA_DIR || path.join(__dirname, 'data-demo');
const db = DB.open(path.join(dataDir, 'amorim.db'));
if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) { console.log('Banco já possui dados — nada a fazer.'); process.exit(0); }

let seed = 42; const rnd = () => (seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296;
const pick = (a) => a[Math.floor(rnd() * a.length)];
const pad = (n) => String(n).padStart(2, '0');
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const dow = (s) => new Date(s + 'T00:00:00Z').getUTCDay();
const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo' }).format(new Date());

const set = db.prepare('INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)');
set.run('address', 'Rua Exemplo, 123 — Centro (endereço de demonstração)');
set.run('whatsapp', '5511999999999'); set.run('instagram', 'barbeariaamorim'); set.run('phone', '(11) 99999-9999');

db.prepare("INSERT INTO users(name,username,pass_hash,role,work_days) VALUES ('Proprietário','admin',?, 'admin','[]')").run(DB.hashPassword('admin12345'));
const bar = db.prepare("INSERT INTO users(name,username,pass_hash,role,bio,work_days) VALUES (?,?,?,'barber',?,?)");
const barbers = [
  ['Carlos Amorim', 'carlos', 'Fundador. Especialista em degradê navalhado e corte na tesoura.', '[1,2,3,4,5,6]'],
  ['Rafael Souza', 'rafael', 'Low, mid e high fade com acabamento impecável.', '[1,2,3,4,5,6]'],
  ['Diego Lima', 'diego', 'Corte americano, infantil e barba.', '[2,3,4,5,6]'],
].map(([n, u, b, w]) => Number(bar.run(n, u, DB.hashPassword('demo12345'), b, w).lastInsertRowid));

const services = db.prepare('SELECT * FROM services').all();
const names = ['Lucas Pereira', 'Marcos Silva', 'João Victor', 'Pedro Henrique', 'Gabriel Santos', 'Matheus Costa', 'Felipe Alves', 'Bruno Rocha', 'Thiago Martins', 'Rodrigo Dias', 'André Gomes', 'Vinícius Lima', 'Eduardo Nunes', 'Leandro Moura', 'Caio Ribeiro'];
const ins = db.prepare('INSERT INTO appointments(barber_id,service_id,service_name,price_cents,client_name,client_phone,date,start_min,end_min,status,source) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
const txi = db.prepare('INSERT INTO transactions(appointment_id,barber_id,date,gross_cents,commission_pct,commission_cents,shop_cents,payment_method) VALUES (?,?,?,?,?,?,?,?)');
const methods = ['pix', 'pix', 'dinheiro', 'cartao_debito', 'cartao_credito'];
const hours = { 6: [9, 17] };
let nAppt = 0;
db.exec('BEGIN');
for (let d = addDays(today, -200); d <= addDays(today, 12); d = addDays(d, 1)) {
  const w = dow(d); if (w === 0) continue;
  const [o, c] = hours[w] || [9, 19];
  for (let bi = 0; bi < barbers.length; bi++) {
    if (!JSON.parse(db.prepare('SELECT work_days FROM users WHERE id=?').get(barbers[bi]).work_days).includes(w)) continue;
    const past = d < today, isToday = d === today;
    const slots = []; for (let m = o * 60; m < c * 60; m += 30) slots.push(m);
    const used = new Set(); const want = past ? 6 + Math.floor(rnd() * 8) : isToday ? 6 : 2 + Math.floor(rnd() * 5);
    for (let k = 0; k < want; k++) {
      const s = pick(slots); const svc = rnd() < 0.18 ? services.find((x) => x.name === 'Corte + Barba') : pick(services.filter((x) => x.duration_min === 30));
      const need = []; for (let m = s; m < s + svc.duration_min; m += 30) need.push(m);
      if (need.some((m) => used.has(m) || m >= c * 60)) continue; need.forEach((m) => used.add(m));
      let status = 'agendado';
      if (past) { const r = rnd(); status = r < 0.86 ? 'concluido' : r < 0.94 ? 'cancelado' : 'faltou'; }
      else if (isToday) status = s < 11 * 60 ? 'concluido' : 'agendado';
      const r = ins.run(barbers[bi], svc.id, svc.name, svc.price_cents, pick(names), '11' + String(900000000 + Math.floor(rnd() * 99999999)), d, s, s + svc.duration_min, status, rnd() < 0.7 ? 'site' : 'balcao');
      nAppt++;
      if (status === 'concluido') { const com = Math.floor(svc.price_cents / 2); txi.run(Number(r.lastInsertRowid), barbers[bi], d, svc.price_cents, 50, com, svc.price_cents - com, pick(methods)); }
    }
  }
}
db.exec('COMMIT');
console.log(`Banco de demonstração criado em ${dataDir} (${nAppt} atendimentos).`);
console.log('Proprietário: admin / admin12345   |   Barbeiros: carlos, rafael, diego / demo12345');
