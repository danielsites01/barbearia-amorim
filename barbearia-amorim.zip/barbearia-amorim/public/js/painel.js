'use strict';
Object.assign(ICON, {
  dash: 'M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z',
  cal: 'M19 4h-1V2h-2v2H8V2H6v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 16H5V10h14v10z',
  users: 'M16 11a3 3 0 1 0-3-3 3 3 0 0 0 3 3zm-8 0a3 3 0 1 0-3-3 3 3 0 0 0 3 3zm0 2c-2.3 0-7 1.2-7 3.5V19h14v-2.5C15 14.2 10.3 13 8 13zm8 0c-.3 0-.6 0-1 .1 1.2.9 2 2 2 3.4V19h6v-2.5c0-2.3-4.7-3.5-7-3.5z',
  tag: 'M21.4 11.6l-9-9A2 2 0 0 0 11 2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 .6 1.4l9 9a2 2 0 0 0 2.8 0l7-7a2 2 0 0 0 0-2.8zM6.5 8A1.5 1.5 0 1 1 8 6.5 1.5 1.5 0 0 1 6.5 8z',
  img: 'M21 19V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2zM8.5 13.5l2.5 3 3.5-4.5 4.5 6H5z',
  chart: 'M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z',
  gear: 'M19.4 13a7.7 7.7 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.3 7.3 0 0 0-1.7-1L15 3h-4l-.4 2.9a7.3 7.3 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.7 7.7 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1a7.3 7.3 0 0 0 1.7 1L11 21h4l.4-2.9a7.3 7.3 0 0 0 1.7-1l2.5 1 2-3.5zM13 15.5A3.5 3.5 0 1 1 16.5 12 3.5 3.5 0 0 1 13 15.5z',
  list: 'M3 5h2v2H3zm4 0h14v2H7zM3 11h2v2H3zm4 0h14v2H7zM3 17h2v2H3zm4 0h14v2H7z',
  user: 'M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0 2c-3.3 0-8 1.7-8 5v1h16v-1c0-3.3-4.7-5-8-5z',
  out: 'M10 17l1.4-1.4L8.8 13H20v-2H8.8l2.6-2.6L10 7l-5 5zM4 5h8V3H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8v-2H4z',
});

const root = $('#root');
const S = { user: null, today: null, services: [], barbers: null };
const PAY = { dinheiro: 'Dinheiro', pix: 'Pix', cartao_debito: 'Cartão de débito', cartao_credito: 'Cartão de crédito' };
const STATUS = { agendado: 'Agendado', concluido: 'Concluído', cancelado: 'Cancelado', faltou: 'Não compareceu' };
const fail = (e) => toast(e.message || 'Erro inesperado.', 'err');
const fmtPhone = (n) => { const d = String(n || '').replace(/\D/g, ''); return d.length === 11 ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}` : d.length === 10 ? `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}` : d; };
const toCents = (v) => Math.round(parseFloat(String(v).replace(/\./g, '').replace(',', '.')) * 100);
const centsToInput = (c) => (c / 100).toFixed(2).replace('.', ',');
const field = (label, input, hint) => h('div', { class: 'field' }, h('label', {}, label), input, hint ? h('span', { class: 'hint' }, hint) : null);
const inp = (props) => h('input', { class: 'input', ...props });

// ---------- modal ----------
function modal(title, body, { submit = 'Salvar', onSubmit, cancel = 'Cancelar' } = {}) {
  const dlg = h('dialog', { class: 'modal' });
  const err = h('div', { class: 'err', hidden: true });
  const ok = h('button', { class: 'btn btn-dark btn-sm', type: 'submit' }, submit);
  const form = h('form', {}, h('h2', {}, title), body, err,
    h('div', { class: 'modal-actions' }, h('button', { class: 'btn btn-ghost-dark btn-sm', type: 'button', onclick: () => dlg.close() }, cancel), onSubmit ? ok : null));
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); err.hidden = true; ok.disabled = true;
    try { if (await onSubmit() !== false) dlg.close(); } catch (ex) { err.textContent = ex.message; err.hidden = false; }
    ok.disabled = false;
  });
  dlg.append(form);
  dlg.addEventListener('close', () => dlg.remove());
  document.body.append(dlg); dlg.showModal();
  return dlg;
}

// ---------- imagem: redimensiona no navegador e envia ----------
function resizeImage(file, max) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      res(c.toDataURL('image/jpeg', 0.86));
    };
    img.onerror = () => rej(new Error('Não foi possível ler a imagem.'));
    img.src = url;
  });
}
function photoInput(current, max = 500) {
  let value = current || '';
  const prev = h('img', { class: 'avatar sm', alt: '', hidden: !value, src: value || null });
  const f = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', class: 'input' });
  f.addEventListener('change', async () => {
    if (!f.files[0]) return;
    try { const r = await api('POST', '/api/admin/upload', { data: await resizeImage(f.files[0], max) }); value = r.url; prev.src = value; prev.hidden = false; toast('Foto carregada.'); } catch (e) { fail(e); }
  });
  return { el: h('div', { style: { display: 'grid', gap: '8px' } }, prev, f), get: () => value };
}

// ---------- seletor de período ----------
function Period(onChange, { presets = ['dia', 'semana', 'mes', 'ano', 'custom'], initial = 'mes' } = {}) {
  const st = { preset: initial, anchor: S.today, from: D.monthStart(S.today), to: S.today };
  const names = { dia: 'Dia', semana: 'Semana', mes: 'Mês', ano: 'Ano', custom: 'Período' };
  const range = () => {
    const a = st.anchor;
    if (st.preset === 'dia') return [a, a];
    if (st.preset === 'semana') { const m = D.mondayOf(a); return [m, D.add(m, 6)]; }
    if (st.preset === 'mes') return [D.monthStart(a), D.monthEnd(a)];
    if (st.preset === 'ano') return [a.slice(0, 4) + '-01-01', a.slice(0, 4) + '-12-31'];
    return [st.from, st.to];
  };
  const label = () => {
    const [f, t] = range();
    if (st.preset === 'dia') return D.long(f);
    if (st.preset === 'semana') return `${D.br(f).slice(0, 5)} a ${D.br(t).slice(0, 5)}`;
    if (st.preset === 'mes') return D.monthLabel(f);
    return st.preset === 'ano' ? f.slice(0, 4) : '';
  };
  const shift = (n) => {
    if (st.preset === 'dia') st.anchor = D.add(st.anchor, n);
    else if (st.preset === 'semana') st.anchor = D.add(st.anchor, 7 * n);
    else if (st.preset === 'mes') st.anchor = D.addMonths(st.anchor, n);
    else st.anchor = `${+st.anchor.slice(0, 4) + n}${st.anchor.slice(4)}`;
    draw(); onChange();
  };
  const el = h('div', { class: 'bar' });
  function draw() {
    clear(el);
    el.append(h('div', { class: 'seg', role: 'group' }, presets.map((p) => h('button', { type: 'button', class: st.preset === p ? 'on' : '', onclick: () => { st.preset = p; if (p !== 'custom') st.anchor = st.anchor || S.today; draw(); onChange(); } }, names[p]))));
    if (st.preset === 'custom') {
      el.append(inp({ type: 'date', class: 'input sm', value: st.from, 'aria-label': 'De', onchange: (e) => { st.from = e.target.value; if (st.from > st.to) st.to = st.from; onChange(); } }), '–',
        inp({ type: 'date', class: 'input sm', value: st.to, 'aria-label': 'Até', onchange: (e) => { st.to = e.target.value; if (st.to < st.from) st.from = st.to; onChange(); } }));
    } else el.append(h('div', { class: 'nav-pn' }, h('button', { type: 'button', 'aria-label': 'Anterior', onclick: () => shift(-1) }, '‹'), h('b', {}, label()), h('button', { type: 'button', 'aria-label': 'Próximo', onclick: () => shift(1) }, '›')));
  }
  draw();
  return { el, range, st, goto: (preset, anchor) => { st.preset = preset; st.anchor = anchor; draw(); onChange(); } };
}

// ---------- gráficos (SVG) ----------
const NS = 'http://www.w3.org/2000/svg';
const sv = (tag, attrs = {}, ...kids) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v); kids.forEach((k) => e.append(k)); return e; };
const short = (c) => (c >= 100000 ? (c / 100000).toFixed(1).replace('.', ',') + 'k' : String(Math.round(c / 100)));
function barChart(data, { height = 230 } = {}) {
  const W = 680, H = height, pl = 6, pr = 6, pt = 26, pb = 30, n = Math.max(data.length, 1);
  const max = Math.max(1, ...data.map((d) => d.value)), bw = (W - pl - pr) / n, ih = H - pt - pb;
  const svg = sv('svg', { viewBox: `0 0 ${W} ${H}`, class: 'chart', role: 'img', 'aria-label': 'Gráfico de barras' });
  [0, .5, 1].forEach((f) => svg.append(sv('line', { class: 'grid', x1: pl, x2: W - pr, y1: pt + ih * (1 - f), y2: pt + ih * (1 - f) })));
  const every = Math.ceil(n / 12);
  data.forEach((d, i) => {
    const bh = Math.max(d.value ? 3 : 0, (d.value / max) * ih), x = pl + i * bw + bw * 0.15, w = bw * 0.7;
    const g = sv('g', {}, sv('title', {}, `${d.tip}: ${brl(d.value)}`), sv('rect', { class: 'bar-r' + (d.hl ? ' hl' : ''), x, y: pt + ih - bh, width: w, height: bh, rx: 3 }));
    if (i % every === 0) g.append(Object.assign(sv('text', { x: x + w / 2, y: H - 10, 'text-anchor': 'middle' }), { textContent: d.label }));
    if (d.value && (d.hl || n <= 12)) g.append(Object.assign(sv('text', { class: 'val', x: x + w / 2, y: pt + ih - bh - 6, 'text-anchor': 'middle' }), { textContent: short(d.value) }));
    svg.append(g);
  });
  return svg;
}
function hbars(rows) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  if (!rows.length) return h('div', { class: 'hint' }, 'Sem dados no período.');
  return h('div', { class: 'hb' }, rows.map((r) => h('div', { class: 'hb-row' }, h('span', {}, r.label), h('div', { class: 'hb-track' }, h('div', { class: 'hb-fill', style: { width: (r.value / max) * 100 + '%' } })), h('span', {}, r.text))));
}
const kpi = (label, value, sub, inv) => h('div', { class: 'kpi' + (inv ? ' inv' : '') }, h('small', {}, label), h('b', {}, value), sub ? h('span', {}, sub) : null);

async function getBarbers() { if (!S.barbers) S.barbers = (await api('GET', '/api/admin/barbers')).barbers; return S.barbers; }
const barberSelect = async (allLabel = 'Todos os barbeiros', onchange) => { const bs = await getBarbers(); return h('select', { class: 'input sm', 'aria-label': 'Barbeiro', onchange }, h('option', { value: '' }, allLabel), bs.map((b) => h('option', { value: b.id }, b.name + (b.active ? '' : ' (inativo)')))); };

// ---------- histórico financeiro ----------
function historyTable(host, getParams, { admin }) {
  const body = h('tbody'), more = h('button', { class: 'btn btn-ghost-dark btn-sm', type: 'button' }, 'Carregar mais'), info = h('p', { class: 'hint', style: { marginTop: '10px' } });
  let offset = 0;
  const cols = ['Data', 'Hora', 'Cliente', 'Serviço', admin ? 'Barbeiro' : null, 'Valor', 'Comissão', 'Barbearia', 'Pagto'].filter(Boolean);
  host.append(h('div', { class: 'tbl-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, cols.map((c, i) => h('th', { class: ['Valor', 'Comissão', 'Barbearia'].includes(c) ? 'num' : '' }, c)))), body)), info, more);
  async function load(reset) {
    if (reset) { offset = 0; clear(body); }
    try {
      const r = await api('GET', `/api/history?${getParams()}&limit=25&offset=${offset}`);
      r.rows.forEach((x) => body.append(h('tr', {}, h('td', {}, D.br(x.date)), h('td', {}, x.start), h('td', {}, x.client_name), h('td', {}, x.service_name), admin ? h('td', {}, x.barber_name) : null, h('td', { class: 'num' }, brl(x.gross_cents)), h('td', { class: 'num' }, brl(x.commission_cents)), h('td', { class: 'num' }, brl(x.shop_cents)), h('td', {}, PAY[x.payment_method] || x.payment_method))));
      offset += r.rows.length; more.hidden = offset >= r.total;
      info.textContent = r.total ? `Mostrando ${offset} de ${r.total} atendimentos concluídos.` : 'Nenhum atendimento concluído no período.';
    } catch (e) { fail(e); }
  }
  more.addEventListener('click', () => load(false));
  load(true);
  return { reload: () => load(true) };
}

// ---------- dashboard (barbeiro: próprio; proprietário: geral/individual) ----------
async function dashboard(host, { admin }) {
  let barber = '';
  const out = h('div', {});
  const p = Period(load, { initial: 'mes' });
  const bar = h('div', { class: 'bar' });
  host.append(p.el, out);
  if (admin) { const sel = await barberSelect('Todos os barbeiros (geral)', (e) => { barber = e.target.value; load(); }); p.el.append(sel); }
  async function load() {
    const [from, to] = p.range();
    if (!from || !to) return;
    const q = `from=${from}&to=${to}${barber ? '&barber=' + barber : ''}`, year = (p.st.preset === 'custom' ? to : p.st.anchor).slice(0, 4);
    out.replaceChildren(h('div', { class: 'loading' }, 'Carregando…'));
    try {
      const [st, mo, rk] = await Promise.all([api('GET', `/api/stats?${q}`), api('GET', `/api/stats/months?year=${year}${barber ? '&barber=' + barber : ''}`), admin && !barber ? api('GET', `/api/admin/ranking?from=${from}&to=${to}`) : null]);
      const t = st.totals, mine = !admin;
      const curM = (p.st.preset === 'custom' ? to : p.st.anchor).slice(0, 7), ci = +curM.slice(5) - 1;
      const cur = mo.months[ci], prev = ci > 0 ? mo.months[ci - 1] : null;
      let delta = null;
      if (prev && prev.gross > 0) { const pc = ((cur.gross - prev.gross) / prev.gross) * 100; delta = h('span', { class: 'delta' }, `${pc >= 0 ? '▲' : '▼'} ${Math.abs(pc).toFixed(0)}% em relação a ${MONTHS[ci - 1]}`); }
      else if (prev) delta = h('span', { class: 'hint' }, `Sem faturamento em ${MONTHS[ci - 1]} para comparar.`);
      const series = st.series.map((s) => ({ label: st.bucket === 'month' ? MON_SHORT[+s.k.slice(5) - 1] : s.k.slice(8), tip: st.bucket === 'month' ? D.monthLabel(s.k + '-01') : D.br(s.k), value: s.gross }));
      const rows = [
        h('div', { class: 'kpis' }, kpi('Faturamento', brl(t.gross), `${t.count} atendimento${t.count === 1 ? '' : 's'} concluído${t.count === 1 ? '' : 's'}`, true),
          kpi(mine ? 'Minha comissão' : 'Comissões dos barbeiros', brl(t.commission), mine ? `${S.user.commission_pct}% dos serviços` : 'a pagar'),
          kpi('Parte da barbearia', brl(t.shop)), kpi('Clientes atendidos', t.count), kpi('Agendamentos futuros', st.upcoming, 'a partir de agora'),
          kpi('Cancelados / faltas', `${st.by_status.cancelado || 0} / ${st.by_status.faltou || 0}`, 'não contabilizados')),
        h('div', { class: 'grid2' },
          h('div', { class: 'card' }, h('h3', {}, st.bucket === 'month' ? 'Rendimento por mês' : 'Rendimento por dia'), series.length ? barChart(series) : h('div', { class: 'hint' }, 'Sem faturamento no período.')),
          h('div', { class: 'card' }, h('h3', {}, `Comparativo mensal — ${year}`), barChart(mo.months.map((m, i) => ({ label: MON_SHORT[i], tip: D.monthLabel(m.month + '-01'), value: m.gross, hl: m.month === curM })), { height: 230 }), delta ? h('div', { style: { marginTop: '8px' } }, delta) : null)),
        h('div', { class: 'grid2' },
          h('div', { class: 'card' }, h('h3', {}, 'Serviços mais realizados'), hbars(st.by_service.map((s) => ({ label: s.name, value: s.gross, text: `${s.count}× · ${brl(s.gross)}` })))),
          rk ? h('div', { class: 'card' }, h('h3', {}, 'Ranking de barbeiros'), rankTable(rk.ranking, (id) => { barber = String(id); const s = $('select', p.el); if (s) s.value = barber; load(); })) : h('div', { class: 'card' }, h('h3', {}, 'Resumo financeiro'), summary(t))),
        h('div', { class: 'card' }, h('h3', {}, 'Histórico de serviços realizados')),
      ];
      out.replaceChildren(...rows);
      historyTable(rows[3], () => q, { admin });
    } catch (e) { out.replaceChildren(h('div', { class: 'err' }, e.message)); }
  }
  const summary = (t) => h('div', {}, [['Faturamento bruto', brl(t.gross)], [`Minha comissão (${S.user.commission_pct}%)`, brl(t.commission)], ['Parte da barbearia', brl(t.shop)]].map(([a, b]) => h('div', { class: 'sumline' }, h('span', {}, a), h('b', {}, b))));
  load();
}
function rankTable(rows, onPick) {
  if (!rows.length) return h('div', { class: 'hint' }, 'Nenhum barbeiro cadastrado.');
  return h('div', { class: 'tbl-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, h('th', {}, '#'), h('th', {}, 'Barbeiro'), h('th', { class: 'num' }, 'Faturou'), h('th', { class: 'num' }, 'Comissão'), h('th', { class: 'num' }, 'Barbearia'), h('th', { class: 'num' }, 'Atend.'))),
    h('tbody', {}, rows.map((r, i) => h('tr', { class: 'clk', title: 'Ver painel individual', onclick: () => onPick(r.id) }, h('td', {}, h('span', { class: 'rank-n' }, i + 1)), h('td', {}, r.name), h('td', { class: 'num' }, brl(r.gross)), h('td', { class: 'num' }, brl(r.commission)), h('td', { class: 'num' }, brl(r.shop)), h('td', { class: 'num' }, r.count))))));
}

// ---------- agenda ----------
function agenda(host, { admin }) {
  let barber = '';
  const out = h('div', {});
  const p = Period(load, { presets: ['dia', 'semana', 'mes', 'ano'], initial: 'dia' });
  const tools = h('div', { class: 'bar' });
  host.append(p.el, tools, out);
  (async () => {
    if (admin) tools.append(await barberSelect('Todos os barbeiros', (e) => { barber = e.target.value; load(); }));
    tools.append(h('button', { class: 'btn btn-dark btn-sm', type: 'button', onclick: () => newAppointment(p.st.preset === 'dia' ? p.st.anchor : S.today, barber, load) }, '+ Novo atendimento'));
  })();
  async function load() {
    const [from, to] = p.range(), mode = p.st.preset;
    out.replaceChildren(h('div', { class: 'loading' }, 'Carregando agenda…'));
    try {
      const r = await api('GET', `/api/agenda?from=${from}&to=${to}${barber ? '&barber=' + barber : ''}`);
      const by = {}; r.appointments.forEach((a) => (by[a.date] ||= []).push(a));
      if (mode === 'dia') return out.replaceChildren(...dayView(by[from] || [], r.blocks, admin, load, from));
      if (mode === 'semana') return out.replaceChildren(h('div', { class: 'week' }, Array.from({ length: 7 }, (_, i) => {
        const d = D.add(from, i), list = by[d] || [];
        return h('div', { class: 'wday' + (d === r.today ? ' today' : '') }, h('h4', { onclick: () => p.goto('dia', d) }, h('span', {}, WD_SHORT[D.dow(d)] + ' ' + d.slice(8)), h('span', {}, list.filter((a) => ['agendado', 'concluido'].includes(a.status)).length || '')),
          list.length ? list.map((a) => h('div', { class: 'wi s-' + a.status, title: STATUS[a.status] }, `${a.start} ${a.client_name}`, h('br'), a.service_name + (admin ? ' · ' + a.barber_name.split(' ')[0] : ''))) : h('div', { class: 'hint' }, '—'));
      })));
      if (mode === 'mes') {
        const pad = (D.dow(from) + 6) % 7, days = +to.slice(8);
        const cells = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'].map((d) => h('div', { class: 'mdow' }, d));
        for (let i = 0; i < pad; i++) cells.push(h('div', { class: 'mcell emp' }));
        for (let d = 1; d <= days; d++) {
          const ds = from.slice(0, 8) + pad2(d), l = (by[ds] || []).filter((a) => ['agendado', 'concluido'].includes(a.status)), v = l.filter((a) => a.status === 'concluido').reduce((s, a) => s + a.price_cents, 0);
          cells.push(h('button', { class: 'mcell' + (ds === r.today ? ' today' : ''), type: 'button', onclick: () => p.goto('dia', ds) }, h('span', {}, d), l.length ? h('span', { class: 'n' }, l.length, h('span', { class: 'u' }, ' atend.')) : h('span', {}), v ? h('span', { class: 'v' }, brl(v)) : h('span', {})));
        }
        return out.replaceChildren(h('div', { class: 'mgrid' }, cells));
      }
      out.replaceChildren(h('div', { class: 'ygrid' }, Array.from({ length: 12 }, (_, i) => {
        const m = `${from.slice(0, 4)}-${pad2(i + 1)}`, l = r.appointments.filter((a) => a.date.startsWith(m)), act = l.filter((a) => ['agendado', 'concluido'].includes(a.status)), v = l.filter((a) => a.status === 'concluido').reduce((s, a) => s + a.price_cents, 0);
        return h('button', { class: 'ycell', type: 'button', onclick: () => p.goto('mes', m + '-01') }, h('h4', {}, MONTHS[i]), h('p', {}, `${act.length} atendimento${act.length === 1 ? '' : 's'}`), h('p', { class: 'hint' }, `${l.filter((a) => a.status === 'agendado').length} agendados · ${brl(v)}`));
      })));
    } catch (e) { out.replaceChildren(h('div', { class: 'err' }, e.message)); }
  }
  load();
}
function dayView(list, blocks, admin, reload, date) {
  const els = blocks.filter((b) => b.date === date).map((b) => h('div', { class: 'blockbar' }, '⛔ Bloqueado' + (b.start ? ` ${b.start}–${b.end}` : ' o dia todo') + (b.reason ? ` — ${b.reason}` : '')));
  if (!list.length) els.push(h('div', { class: 'empty p' }, 'Nenhum agendamento neste dia.'));
  list.forEach((a) => els.push(apptCard(a, admin, reload)));
  const act = list.filter((a) => a.status === 'agendado').length, done = list.filter((a) => a.status === 'concluido');
  if (list.length) els.unshift(h('p', { class: 'hint', style: { marginBottom: '12px' } }, `${act} agendado${act === 1 ? '' : 's'} · ${done.length} concluído${done.length === 1 ? '' : 's'} · ${brl(done.reduce((s, a) => s + a.price_cents, 0))} faturado`));
  return els;
}
function apptCard(a, admin, reload) {
  const isPast = a.date <= S.today;
  const btn = (txt, cls, fn) => h('button', { class: 'btn btn-sm ' + cls, type: 'button', onclick: fn }, txt);
  const acts = [];
  if (a.status === 'agendado') {
    if (isPast) acts.push(btn('Concluir', 'btn-dark', () => concludeModal(a, reload)), btn('Faltou', 'btn-ghost-dark', () => setStatus(a, 'faltou', reload)));
    acts.push(btn('Cancelar', 'btn-ghost-dark danger', () => { if (confirm(`Cancelar o atendimento de ${a.client_name}?`)) setStatus(a, 'cancelado', reload); }));
  } else if (a.status === 'concluido') {
    acts.push(h('span', { class: 'badge concluido' }, 'Concluído'));
    if (admin) acts.push(btn('Reabrir', 'btn-ghost-dark', () => { if (confirm('Reabrir este atendimento? O lançamento financeiro será estornado.')) setStatus(a, 'agendado', reload); }));
  } else acts.push(h('span', { class: 'badge ' + a.status }, STATUS[a.status]), btn('Reabrir', 'btn-ghost-dark', () => setStatus(a, 'agendado', reload)));
  return h('div', { class: 'appt s-' + a.status },
    h('div', { class: 't' }, a.start, h('small', {}, 'até ' + a.end)),
    h('div', { class: 'c' }, h('b', {}, a.client_name), h('span', {}, `${a.service_name} · ${brl(a.price_cents)}` + (admin ? ` · ${a.barber_name}` : '')), h('br'),
      a.client_phone ? h('a', { href: 'tel:' + a.client_phone }, fmtPhone(a.client_phone)) : h('span', {}, 'Sem telefone'),
      a.source === 'balcao' ? h('span', {}, ' · balcão') : null,
      a.status === 'concluido' ? h('span', {}, ` · ${PAY[a.payment_method] || ''} · comissão ${brl(a.commission_cents)} / barbearia ${brl(a.shop_cents)}`) : null),
    h('div', { class: 'acts' }, acts));
}
async function setStatus(a, status, reload, extra = {}) {
  try { await api('PATCH', `/api/appointments/${a.id}/status`, { status, ...extra }); toast('Atendimento atualizado.'); reload(); } catch (e) { fail(e); reload(); }
}
function concludeModal(a, reload) {
  let method = 'pix';
  const half = S.user.role === 'barber' ? Math.floor((a.price_cents * S.user.commission_pct) / 100) : null;
  const body = h('div', {}, h('p', { style: { marginBottom: '14px', fontWeight: 700 } }, `${a.client_name} — ${a.service_name}`),
    h('div', { class: 'sumline' }, h('span', {}, 'Valor do serviço'), h('b', {}, brl(a.price_cents))),
    half !== null ? h('div', { class: 'sumline' }, h('span', {}, `Sua comissão (${S.user.commission_pct}%)`), h('b', {}, brl(half))) : null,
    h('div', { class: 'lbl', style: { margin: '16px 0 8px' } }, 'Forma de pagamento'),
    h('div', { class: 'pay' }, Object.entries(PAY).map(([k, v]) => h('label', {}, h('input', { type: 'radio', name: 'pay', value: k, checked: k === 'pix', onchange: () => (method = k) }), v))));
  modal('Concluir atendimento', body, { submit: 'Confirmar pagamento', onSubmit: async () => { await api('PATCH', `/api/appointments/${a.id}/status`, { status: 'concluido', payment_method: method }); toast('Atendimento concluído e comissão registrada.'); reload(); } });
}
async function newAppointment(date, barberId, reload) {
  const admin = S.user.role === 'admin';
  const bs = admin ? await getBarbers() : [];
  const bsel = admin ? h('select', { class: 'input' }, bs.filter((b) => b.active).map((b) => h('option', { value: b.id }, b.name))) : null;
  if (admin && barberId) bsel.value = barberId;
  const ssel = h('select', { class: 'input' }, S.services.map((s) => h('option', { value: s.id }, `${s.name} — ${brl(s.price_cents)} (${s.duration_min} min)`)));
  const dt = inp({ type: 'date', value: date }), tsel = h('select', { class: 'input' }), name = inp({ type: 'text', maxlength: 80, placeholder: 'Nome do cliente', required: true }), phone = inp({ type: 'tel', placeholder: '(opcional)' });
  async function slots() {
    clear(tsel); const b = admin ? bsel.value : '';
    if (!dt.value || (admin && !b)) return;
    try {
      const svc = S.services.find((s) => s.id == ssel.value); const r = await api('GET', `/api/slots?date=${dt.value}${admin ? '&barber=' + b : ''}`);
      const ok = r.slots.filter((s) => s.max_min >= svc.duration_min);
      if (!ok.length) tsel.append(h('option', { value: '' }, 'Sem horários livres')); else ok.forEach((s) => tsel.append(h('option', { value: s.time }, s.time)));
    } catch (e) { fail(e); }
  }
  [dt, ssel, bsel].forEach((e) => e && e.addEventListener('change', slots));
  slots();
  modal('Novo atendimento', h('div', {}, admin ? field('Barbeiro', bsel) : null, field('Cliente', name), field('Telefone', phone), field('Serviço', ssel), h('div', { class: 'row2' }, field('Data', dt), field('Horário', tsel))),
    { submit: 'Lançar na agenda', onSubmit: async () => { if (!tsel.value) throw new Error('Escolha um horário livre.'); await api('POST', '/api/appointments', { barber_id: admin ? +bsel.value : undefined, service_id: +ssel.value, date: dt.value, time: tsel.value, client_name: name.value, client_phone: phone.value }); toast('Atendimento lançado.'); reload(); } });
}

// ---------- telas do proprietário ----------
async function viewBarbers(host) {
  S.barbers = null;
  const list = h('div', { class: 'cards' });
  host.append(h('div', { class: 'bar' }, h('button', { class: 'btn btn-dark btn-sm', onclick: () => barberForm(null) }, '+ Novo barbeiro')), list);
  const load = async () => {
    S.barbers = null; const bs = await getBarbers(); clear(list);
    if (!bs.length) list.append(h('div', { class: 'empty p' }, 'Nenhum barbeiro cadastrado. Clique em “Novo barbeiro”.'));
    bs.forEach((b) => list.append(h('div', { class: 'card pcard' + (b.active ? '' : ' off-tag') }, avatar(b), h('div', { style: { flex: 1 } }, h('b', {}, b.name), h('small', {}, `login: ${b.username} · comissão ${b.commission_pct}%`), h('small', {}, 'Trabalha: ' + ([1, 2, 3, 4, 5, 6, 0].filter((d) => b.work_days.includes(d)).map((d) => WD_SHORT[d]).join(', ') || '—') + (b.active ? '' : ' · INATIVO'))), h('button', { class: 'btn btn-ghost-dark btn-sm', onclick: () => barberForm(b) }, 'Editar'))));
  };
  function barberForm(b) {
    const name = inp({ value: b?.name || '', required: true, maxlength: 60 }), user = inp({ value: b?.username || '', required: true, maxlength: 30, autocomplete: 'off' }), pw = inp({ type: 'text', autocomplete: 'new-password', placeholder: b ? 'Deixe em branco para manter' : 'Mínimo 8 caracteres' });
    const bio = h('textarea', { class: 'input', maxlength: 300, value: b?.bio || '' }), ph = photoInput(b?.photo), com = inp({ type: 'number', min: 0, max: 100, value: b?.commission_pct ?? 50 });
    const days = h('div', { class: 'days' }, [1, 2, 3, 4, 5, 6, 0].map((d) => h('label', {}, h('input', { type: 'checkbox', value: d, checked: b ? b.work_days.includes(d) : d !== 0 }), WD_SHORT[d])));
    const act = h('input', { type: 'checkbox', checked: b ? b.active : true });
    modal(b ? 'Editar barbeiro' : 'Novo barbeiro', h('div', {}, field('Nome', name), h('div', { class: 'row2' }, field('Login', user), field(b ? 'Nova senha' : 'Senha', pw)), field('Apresentação (aparece no agendamento)', bio), field('Foto', ph.el, 'A foto é redimensionada automaticamente.'), field('Dias de trabalho', days), field('Comissão (%)', com, 'Padrão da barbearia: 50%'), b ? h('label', { class: 'days' }, h('label', {}, act, 'Barbeiro ativo (aparece no agendamento e pode entrar no painel)')) : null),
      { onSubmit: async () => {
        const data = { name: name.value, username: user.value, bio: bio.value, photo: ph.get(), commission_pct: +com.value, work_days: $$('input', days).filter((i) => i.checked).map((i) => +i.value), active: b ? act.checked : true, password: pw.value || undefined };
        const r = b ? await api('PUT', `/api/admin/barbers/${b.id}`, data) : await api('POST', '/api/admin/barbers', data);
        toast(b ? 'Barbeiro atualizado.' : 'Barbeiro cadastrado.'); if (r.future_appointments && !data.active) toast(`Atenção: ${r.future_appointments} agendamento(s) futuro(s) continuam na agenda dele.`, 'err'); load();
      } });
  }
  load();
}
async function viewServices(host) {
  const box = h('div', { class: 'card' });
  host.append(h('div', { class: 'bar' }, h('button', { class: 'btn btn-dark btn-sm', onclick: () => form(null) }, '+ Novo serviço')), box);
  async function load() {
    const { services } = await api('GET', '/api/admin/services'); S.services = services.filter((s) => s.active); clear(box);
    box.append(h('div', { class: 'tbl-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, h('th', {}, 'Serviço'), h('th', { class: 'num' }, 'Preço'), h('th', { class: 'num' }, 'Duração'), h('th', {}, 'Situação'), h('th', {}))),
      h('tbody', {}, services.map((s) => h('tr', { class: s.active ? '' : 'off-tag' }, h('td', {}, s.name), h('td', { class: 'num' }, brl(s.price_cents)), h('td', { class: 'num' }, s.duration_min + ' min'), h('td', {}, s.active ? 'Ativo' : 'Inativo'), h('td', { class: 'num' }, h('button', { class: 'btn btn-ghost-dark btn-sm', onclick: () => form(s) }, 'Editar'))))))));
  }
  function form(s) {
    const name = inp({ value: s?.name || '', required: true }), price = inp({ value: s ? centsToInput(s.price_cents) : '', inputmode: 'decimal', placeholder: '40,00' }), dur = inp({ type: 'number', min: 5, max: 240, step: 5, value: s?.duration_min || 30 }), act = h('input', { type: 'checkbox', checked: s ? !!s.active : true });
    modal(s ? 'Editar serviço' : 'Novo serviço', h('div', {}, field('Nome', name), h('div', { class: 'row2' }, field('Preço (R$)', price), field('Duração (min)', dur, 'Use múltiplos do intervalo da agenda (ex.: 30, 60).')), h('div', { class: 'days' }, h('label', {}, act, 'Serviço ativo'))),
      { onSubmit: async () => { const c = toCents(price.value); if (isNaN(c)) throw new Error('Informe um preço válido.'); const data = { name: name.value, price_cents: c, duration_min: +dur.value, active: act.checked }; s ? await api('PUT', `/api/admin/services/${s.id}`, data) : await api('POST', '/api/admin/services', data); toast('Serviço salvo.'); load(); } });
  }
  load();
}
async function viewHours(host) {
  const { settings: st } = await api('GET', '/api/admin/settings');
  const rows = [1, 2, 3, 4, 5, 6, 0].map((d) => {
    const v = st.hours[d], closed = h('input', { type: 'checkbox', checked: !v }), o = inp({ type: 'time', class: 'input sm', value: v ? v[0] : '09:00' }), c = inp({ type: 'time', class: 'input sm', value: v ? v[1] : '19:00' });
    return { d, closed, o, c, el: h('div', { class: 'hrs-row' }, h('span', {}, WEEKDAYS[d]), h('label', { class: 'days', style: { gap: 0 } }, h('label', {}, closed, 'Fechado')), h('div', { class: 'tms' }, o, 'às', c)) };
  });
  const slot = h('select', { class: 'input sm' }, [10, 15, 20, 30, 40, 45, 60].map((n) => h('option', { value: n, selected: n === st.slot_minutes }, n + ' min'))), adv = inp({ type: 'number', class: 'input sm', min: 1, max: 365, value: st.advance_days }), lead = inp({ type: 'number', class: 'input sm', min: 0, max: 1440, value: st.min_lead_minutes });
  host.append(h('div', { class: 'grid2' },
    h('div', { class: 'card' }, h('h3', {}, 'Horário de funcionamento'), h('div', { class: 'hrs' }, rows.map((r) => r.el)),
      h('div', { class: 'row2' }, field('Intervalo da agenda', slot), field('Agendar com até (dias)', adv)), field('Antecedência mínima (minutos)', lead, 'Evita agendamentos “para daqui a 5 minutos”.'),
      h('button', { class: 'btn btn-dark btn-sm', onclick: async () => { try { const hours = {}; rows.forEach((r) => (hours[r.d] = r.closed.checked ? null : [r.o.value, r.c.value])); await api('PUT', '/api/admin/settings', { hours, slot_minutes: +slot.value, advance_days: +adv.value, min_lead_minutes: +lead.value }); toast('Horários salvos.'); } catch (e) { fail(e); } } }, 'Salvar horários'),
      h('p', { class: 'hint', style: { marginTop: '10px' } }, 'Os dias de trabalho de cada barbeiro são definidos na tela Barbeiros.')),
    await blocksCard()));
}
async function blocksCard() {
  const bs = await getBarbers(), list = h('div'), date = inp({ type: 'date', value: S.today }), whole = h('input', { type: 'checkbox', checked: true }), t1 = inp({ type: 'time', class: 'input sm', value: '12:00', disabled: true }), t2 = inp({ type: 'time', class: 'input sm', value: '14:00', disabled: true }), reason = inp({ placeholder: 'Motivo (opcional)', maxlength: 120 });
  const who = h('select', { class: 'input' }, h('option', { value: '' }, 'Toda a barbearia'), bs.filter((b) => b.active).map((b) => h('option', { value: b.id }, b.name)));
  whole.addEventListener('change', () => { t1.disabled = t2.disabled = whole.checked; });
  async function load() {
    const { blocks } = await api('GET', '/api/admin/blocks'); clear(list);
    if (!blocks.length) list.append(h('div', { class: 'hint' }, 'Nenhum bloqueio futuro.'));
    blocks.forEach((b) => list.append(h('div', { class: 'sumline' }, h('span', {}, `${D.br(b.date)} · ${b.start ? b.start + '–' + b.end : 'dia todo'} · ${b.barber_name || 'Toda a barbearia'}${b.reason ? ' — ' + b.reason : ''}`), h('button', { class: 'btn btn-sm danger', type: 'button', onclick: async () => { await api('DELETE', `/api/admin/blocks/${b.id}`); load(); } }, 'Remover'))));
  }
  load();
  return h('div', { class: 'card' }, h('h3', {}, 'Bloquear datas e horários'), field('Quem', who), h('div', { class: 'row2' }, field('Data', date), field('Motivo', reason)),
    h('div', { class: 'days', style: { marginBottom: '12px' } }, h('label', {}, whole, 'Dia inteiro'), t1, 'às', t2),
    h('button', { class: 'btn btn-dark btn-sm', onclick: async () => { try { const r = await api('POST', '/api/admin/blocks', { barber_id: who.value ? +who.value : null, date: date.value, start: whole.checked ? undefined : t1.value, end: whole.checked ? undefined : t2.value, reason: reason.value }); toast(r.conflicts ? `Bloqueio criado. Atenção: ${r.conflicts} agendamento(s) já existem nesse período.` : 'Bloqueio criado.', r.conflicts ? 'err' : 'ok'); load(); } catch (e) { fail(e); } } }, 'Criar bloqueio'),
    h('h3', { style: { margin: '22px 0 8px' } }, 'Bloqueios futuros'), list);
}
async function viewGallery(host) {
  const { categories } = await api('GET', '/api/admin/gallery');
  const grid = h('div', { class: 'gal-adm' }), file = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', class: 'input' }), cat = h('select', { class: 'input' }, categories.map((c) => h('option', { value: c.slug }, c.name))), cap = inp({ placeholder: 'Legenda (opcional)', maxlength: 80 });
  host.append(h('div', { class: 'card', style: { marginBottom: '16px' } }, h('h3', {}, 'Adicionar foto à galeria'), h('div', { class: 'row2' }, field('Foto', file), field('Categoria', cat)), field('Legenda', cap),
    h('button', { class: 'btn btn-dark btn-sm', onclick: async (e) => { if (!file.files[0]) return toast('Escolha uma foto.', 'err'); e.target.disabled = true; try { const up = await api('POST', '/api/admin/upload', { data: await resizeImage(file.files[0], 1400) }); await api('POST', '/api/admin/gallery', { category: cat.value, file: up.url, caption: cap.value }); toast('Foto adicionada.'); file.value = ''; cap.value = ''; load(); } catch (x) { fail(x); } e.target.disabled = false; } }, 'Enviar foto')), grid);
  async function load() {
    const { gallery } = await api('GET', '/api/admin/gallery'); clear(grid);
    gallery.forEach((g) => grid.append(h('figure', {}, h('img', { src: g.file, alt: g.caption, loading: 'lazy' }), h('figcaption', {}, h('span', {}, categories.find((c) => c.slug === g.category)?.name || ''), h('button', { type: 'button', onclick: async () => { if (confirm('Remover esta foto da galeria?')) { await api('DELETE', `/api/admin/gallery/${g.id}`); load(); } } }, 'Remover')))));
  }
  load();
}
async function viewReports(host) {
  let by = 'month', barber = '';
  const out = h('div', { class: 'card' });
  const p = Period(load, { presets: ['mes', 'ano', 'custom'], initial: 'mes' });
  const gsel = h('select', { class: 'input sm', 'aria-label': 'Agrupar por', onchange: (e) => { by = e.target.value; load(); } }, [['day', 'Por dia'], ['month', 'Por mês'], ['year', 'Por ano']].map(([v, l]) => h('option', { value: v, selected: v === by }, l)));
  const bsel = await barberSelect('Todos os barbeiros', (e) => { barber = e.target.value; load(); });
  const csv = h('a', { class: 'btn btn-ghost-dark btn-sm', href: '#', download: '' }, 'Baixar CSV');
  p.el.append(gsel, bsel, csv); host.append(p.el, out);
  async function load() {
    const [from, to] = p.range(); const q = `from=${from}&to=${to}&by=${by}${barber ? '&barber=' + barber : ''}`; csv.href = `/api/admin/report.csv?${q}`;
    try {
      const r = await api('GET', `/api/admin/report?${q}`); const T = r.totals;
      out.replaceChildren(r.rows.length ? h('div', { class: 'tbl-wrap' }, h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, h('th', {}, 'Período'), h('th', {}, 'Barbeiro'), h('th', { class: 'num' }, 'Atend.'), h('th', { class: 'num' }, 'Faturamento'), h('th', { class: 'num' }, 'Comissão'), h('th', { class: 'num' }, 'Barbearia'))),
        h('tbody', {}, r.rows.map((x) => h('tr', {}, h('td', {}, by === 'day' ? D.br(x.period) : by === 'month' ? D.monthLabel(x.period + '-01') : x.period), h('td', {}, x.barber_name), h('td', { class: 'num' }, x.count), h('td', { class: 'num' }, brl(x.gross)), h('td', { class: 'num' }, brl(x.commission)), h('td', { class: 'num' }, brl(x.shop))))),
        h('tfoot', {}, h('tr', {}, h('td', { colspan: 2 }, 'Total'), h('td', { class: 'num' }, T.count), h('td', { class: 'num' }, brl(T.gross)), h('td', { class: 'num' }, brl(T.commission)), h('td', { class: 'num' }, brl(T.shop)))))) : h('div', { class: 'empty p' }, 'Nenhum atendimento concluído no período.'));
    } catch (e) { out.replaceChildren(h('div', { class: 'err' }, e.message)); }
  }
  load();
}
function passwordCard() {
  const cur = inp({ type: 'password', autocomplete: 'current-password' }), nw = inp({ type: 'password', autocomplete: 'new-password', placeholder: 'Mínimo 8 caracteres' });
  return h('div', { class: 'card' }, h('h3', {}, 'Alterar minha senha'), field('Senha atual', cur), field('Nova senha', nw),
    h('button', { class: 'btn btn-dark btn-sm', onclick: async () => { try { await api('POST', '/api/auth/password', { current: cur.value, new: nw.value }); cur.value = nw.value = ''; toast('Senha alterada.'); } catch (e) { fail(e); } } }, 'Salvar nova senha'));
}
async function viewSettings(host) {
  const { settings: s } = await api('GET', '/api/admin/settings');
  const f = {}; const mk = (k, label, props = {}, hint) => { f[k] = props.as === 'ta' ? h('textarea', { class: 'input', value: s[k] || '' }) : inp({ value: s[k] || '', ...props }); return field(label, f[k], hint); };
  host.append(h('div', { class: 'grid2' }, h('div', { class: 'card' }, h('h3', {}, 'Dados da barbearia (aparecem no site)'),
    mk('shop_name', 'Nome'), mk('tagline', 'Frase de destaque'), mk('about', 'Apresentação', { as: 'ta' }), mk('address', 'Endereço'), mk('maps_url', 'Link do Google Maps (opcional)', { placeholder: 'https://maps.google.com/...' }),
    h('div', { class: 'row2' }, mk('whatsapp', 'WhatsApp', { placeholder: '(11) 91234-5678' }), mk('phone', 'Telefone fixo (opcional)')), mk('instagram', 'Instagram', { placeholder: '@barbeariaamorim' }),
    h('button', { class: 'btn btn-dark btn-sm', onclick: async () => { try { const d = {}; for (const k in f) d[k] = f[k].value; await api('PUT', '/api/admin/settings', d); toast('Dados salvos.'); } catch (e) { fail(e); } } }, 'Salvar')), passwordCard()));
}

// ---------- estrutura / navegação ----------
const NAV = {
  barber: [['resumo', 'dash', 'Resumo'], ['agenda', 'cal', 'Agenda'], ['historico', 'list', 'Histórico'], ['conta', 'user', 'Conta']],
  admin: [['geral', 'dash', 'Visão geral'], ['agendas', 'cal', 'Agendas'], ['barbeiros', 'users', 'Barbeiros'], ['servicos', 'tag', 'Serviços'], ['horarios', 'clock', 'Horários'], ['galeria', 'img', 'Galeria'], ['relatorios', 'chart', 'Relatórios'], ['config', 'gear', 'Dados']],
};
const TITLES = { resumo: 'Meu resumo', agenda: 'Minha agenda', historico: 'Histórico de atendimentos', conta: 'Minha conta', geral: 'Visão geral', agendas: 'Agendas', barbeiros: 'Barbeiros', servicos: 'Serviços e preços', horarios: 'Horários e bloqueios', galeria: 'Galeria de cortes', relatorios: 'Relatórios', config: 'Dados da barbearia' };
const VIEWS = {
  resumo: (m) => dashboard(m, { admin: false }), agenda: (m) => agenda(m, { admin: false }),
  historico: (m) => { const p = Period(() => t.reload(), { presets: ['mes', 'ano', 'custom'] }); m.append(p.el); const box = h('div', { class: 'card' }); m.append(box); const t = historyTable(box, () => { const [f, to] = p.range(); return `from=${f}&to=${to}`; }, { admin: false }); },
  conta: (m) => m.append(h('div', { class: 'grid2' }, h('div', { class: 'card' }, h('h3', {}, S.user.name), h('p', {}, 'Sua comissão é de ', h('b', {}, S.user.commission_pct + '%'), ' sobre o valor dos serviços concluídos.'), h('p', { class: 'hint', style: { marginTop: '8px' } }, 'Você vê somente a sua agenda e os seus resultados.')), passwordCard())),
  geral: (m) => dashboard(m, { admin: true }), agendas: (m) => agenda(m, { admin: true }), barbeiros: viewBarbers, servicos: viewServices, horarios: viewHours, galeria: viewGallery, relatorios: viewReports, config: viewSettings,
};

async function showApp() {
  const nav = NAV[S.user.role], first = nav[0][0];
  if (S.user.role === 'admin') { try { const l = await api('GET', '/api/admin/services'); S.services = l.services.filter((s) => s.active); } catch {} }
  else S.services = (await api('GET', '/api/public/info')).services;
  const logout = async () => { await api('POST', '/api/auth/logout', {}); location.hash = ''; boot(); };
  const main = h('main', { class: 'main', id: 'main' });
  const side = h('nav', { class: 'side', 'aria-label': 'Painel' },
    h('a', { class: 'brand', href: '/' }, h('img', { src: '/img/logo.png', alt: '' }), h('span', {}, 'Amorim', h('small', {}, S.user.role === 'admin' ? 'PROPRIETÁRIO' : 'BARBEIRO'))),
    nav.map(([id, ic, label]) => h('button', { class: 'nav-b', 'data-id': id, onclick: () => (location.hash = '#/' + id) }, icon(ic, 20), label)),
    h('div', { class: 'grow' }), h('div', { class: 'who' }, h('b', {}, S.user.name), 'Sessão ativa'),
    h('button', { class: 'nav-b', onclick: logout }, icon('out', 20), 'Sair'));
  const mtop = h('div', { class: 'mtop' }, h('a', { class: 'brand', href: '/' }, h('img', { src: '/img/logo.png', alt: '' }), 'Amorim'), h('button', { class: 'btn btn-ghost-light btn-sm', onclick: logout }, 'Sair'));
  root.replaceChildren(h('div', {}, mtop, h('div', { class: 'shell' }, side, main)));
  async function route() {
    let id = location.hash.replace('#/', ''); if (!nav.some((n) => n[0] === id)) id = first;
    $$('.nav-b[data-id]').forEach((b) => b.classList.toggle('on', b.dataset.id === id));
    clear(main).append(h('div', { class: 'top' }, h('h1', {}, TITLES[id])));
    window.scrollTo(0, 0);
    try { await VIEWS[id](main); } catch (e) { main.append(h('div', { class: 'err' }, e.message)); }
  }
  window.onhashchange = route; route();
}

function showLogin(msg) {
  const user = inp({ id: 'u', autocomplete: 'username', required: true, autocapitalize: 'none' }), pw = inp({ id: 'p', type: 'password', autocomplete: 'current-password', required: true }), err = h('div', { class: 'err', hidden: !msg }, msg);
  const btn = h('button', { class: 'btn btn-dark', type: 'submit' }, 'Entrar');
  const form = h('form', { class: 'login-card' }, h('img', { src: '/img/logo.png', alt: 'Barbearia Amorim' }), h('h1', {}, 'Área da equipe'), h('p', { class: 'sub' }, 'Acesso exclusivo para barbeiros e proprietário.'), err,
    h('div', { class: 'field' }, h('label', { for: 'u' }, 'Login'), user), h('div', { class: 'field' }, h('label', { for: 'p' }, 'Senha'), pw), btn, h('a', { class: 'login-back', href: '/' }, '← Voltar ao site'));
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); err.hidden = true; btn.disabled = true;
    try { await api('POST', '/api/auth/login', { username: user.value, password: pw.value }); boot(); } catch (ex) { err.textContent = ex.message; err.hidden = false; btn.disabled = false; pw.value = ''; pw.focus(); }
  });
  root.replaceChildren(h('div', { class: 'login-wrap' }, form)); user.focus();
}

async function boot() {
  try {
    const me = await api('GET', '/api/auth/me');
    S.today = me.today;
    if (!me.user) return showLogin();
    S.user = me.user; S.barbers = null;
    await showApp();
  } catch (e) { showLogin(e.message); }
}
boot();
