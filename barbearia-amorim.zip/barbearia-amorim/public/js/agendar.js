'use strict';
(async function () {
  const stage = $('#stage');
  let info;
  try { info = await api('GET', '/api/public/info'); } catch { stage.append(h('div', { class: 'err' }, 'Não foi possível carregar a agenda. Atualize a página.')); return; }
  const { shop, services, barbers } = info;
  const S = { barber: null, date: null, time: null, maxMin: 0, cursor: null, today: null, maxDate: null };

  const NAMES = ['Escolha o barbeiro', 'Escolha o dia', 'Escolha o horário', 'Seus dados e serviço'];
  function header(step) {
    $$('#stepper i').forEach((e, i) => e.classList.toggle('on', i <= step));
    $('#stepname').textContent = step < 4 ? `Passo ${step + 1} de 4 — ${NAMES[step]}` : 'Agendamento confirmado';
    const sm = clear($('#summary'));
    if (step > 4) return;
    if (S.barber && step > 0) sm.append(h('button', { class: 'pill', type: 'button', onclick: stepBarber, title: 'Trocar barbeiro' }, '✂ ' + S.barber.name));
    if (S.date && step > 1) sm.append(h('button', { class: 'pill', type: 'button', onclick: stepDate, title: 'Trocar dia' }, '📅 ' + D.br(S.date)));
    if (S.time && step > 2) sm.append(h('button', { class: 'pill', type: 'button', onclick: stepTime, title: 'Trocar horário' }, '🕒 ' + S.time));
    if (step >= 4) $('#stepper').style.display = 'none';
  }
  const view = (...kids) => { clear(stage); stage.append(h('div', { class: 'step' }, ...kids)); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const back = (fn, label = 'Voltar') => h('button', { class: 'back', type: 'button', onclick: fn }, '← ' + label);

  // 1 — barbeiro
  function stepBarber() {
    header(0);
    if (!barbers.length) return view(h('div', { class: 'empty' }, 'Os agendamentos online ainda não estão disponíveis. Fale conosco pelo WhatsApp.'));
    view(h('div', { class: 'pick-grid' }, barbers.map((b) => h('button', { class: 'pick', type: 'button', onclick: () => { S.barber = b; S.date = null; S.time = null; S.cursor = null; stepDate(); } },
      avatar(b), h('h3', {}, b.name), h('p', {}, b.bio || 'Barbeiro da equipe Amorim')))));
  }

  // 2 — dia
  const loadDays = (cursor) => api('GET', `/api/public/days?barber=${S.barber.id}&month=${cursor.slice(0, 7)}`);
  async function stepDate() {
    header(1);
    S.time = null;
    const box = h('div', {}, h('div', { class: 'empty' }, 'Carregando agenda…'));
    view(back(stepBarber, 'Trocar barbeiro'), box);
    try {
      let cursor = S.cursor || D.monthStart(new Date().toISOString().slice(0, 10));
      let data = await loadDays(cursor);
      if (!S.cursor) {
        const real = D.monthStart(data.today);
        if (real !== cursor) { cursor = real; data = await loadDays(cursor); }
        for (let i = 0; i < 3 && !Object.keys(data.days).length && D.addMonths(cursor, 1) <= data.max_date; i++) { cursor = D.addMonths(cursor, 1); data = await loadDays(cursor); }
      }
      S.cursor = cursor;
      renderCal(box, data);
    } catch (e) { clear(box).append(h('div', { class: 'err' }, e.message)); }
  }
  function renderCal(box, data) {
    const c = S.cursor, first = D.monthStart(c), pad = D.dow(first), days = D.monthEnd(first).slice(8);
    const grid = h('div', { class: 'cal-grid' }, WD_SHORT.map((d) => h('div', { class: 'cal-dow' }, d[0] + d.slice(1, 3).toLowerCase())));
    for (let i = 0; i < pad; i++) grid.append(h('span'));
    for (let d = 1; d <= +days; d++) {
      const ds = `${c.slice(0, 7)}-${pad2(d)}`, free = data.days[ds];
      grid.append(h('button', { class: 'cal-day ' + (free ? 'free' : 'off') + (ds === data.today ? ' today' : ''), type: 'button', disabled: !free, 'aria-label': free ? `${D.long(ds)} — ${free} horários livres` : `${D.long(ds)} — indisponível`, onclick: () => { S.date = ds; stepTime(); } }, d));
    }
    const prevOk = D.monthStart(c) > D.monthStart(data.today), nextOk = D.addMonths(c, 1) <= data.max_date;
    const move = (n) => { S.cursor = D.addMonths(c, n); stepDateReload(); };
    clear(box).append(
      h('p', { class: 'hint', style: { marginBottom: '14px' } }, 'Dias com borda estão disponíveis para ', h('b', {}, S.barber.name), '.'),
      h('div', { class: 'cal' },
        h('div', { class: 'cal-head' }, h('button', { class: 'cal-nav', type: 'button', disabled: !prevOk, 'aria-label': 'Mês anterior', onclick: () => move(-1) }, '‹'), h('b', {}, D.monthLabel(c)), h('button', { class: 'cal-nav', type: 'button', disabled: !nextOk, 'aria-label': 'Próximo mês', onclick: () => move(1) }, '›')),
        grid,
        h('div', { class: 'cal-legend' }, 'Dias riscados: sem horários disponíveis.')));
    if (!Object.keys(data.days).length) box.append(h('div', { class: 'empty', style: { marginTop: '16px', maxWidth: '460px' } }, 'Sem horários livres neste mês. Veja o próximo mês →'));
  }
  async function stepDateReload() {
    const box = $('.step > div:last-child');
    try { renderCal(box, await api('GET', `/api/public/days?barber=${S.barber.id}&month=${S.cursor.slice(0, 7)}`)); } catch (e) { toast(e.message, 'err'); }
  }

  // 3 — horário
  async function stepTime() {
    header(2);
    S.time = null;
    const box = h('div', {}, h('div', { class: 'empty' }, 'Carregando horários…'));
    view(back(stepDate, 'Trocar dia'), h('h2', { style: { fontSize: '2rem', marginBottom: '18px' } }, D.long(S.date)), box);
    try {
      const { slots } = await api('GET', `/api/public/slots?barber=${S.barber.id}&date=${S.date}`);
      if (!slots.length) return clear(box).append(h('div', { class: 'empty' }, 'Todos os horários deste dia foram preenchidos. Escolha outro dia.'));
      clear(box).append(h('p', { class: 'hint', style: { marginBottom: '14px' } }, `${slots.length} horário${slots.length > 1 ? 's' : ''} livre${slots.length > 1 ? 's' : ''} com ${S.barber.name}:`),
        h('div', { class: 'slot-grid' }, slots.map((s) => h('button', { class: 'slot', type: 'button', onclick: () => { S.time = s.time; S.maxMin = s.max_min; stepDetails(); } }, s.time))));
    } catch (e) { clear(box).append(h('div', { class: 'err' }, e.message)); }
  }

  // 4 — dados e serviço
  function stepDetails() {
    header(3);
    let chosen = null;
    const err = h('div', { class: 'err', hidden: true });
    const name = h('input', { class: 'input', id: 'nm', type: 'text', autocomplete: 'name', maxlength: 80, required: true, placeholder: 'Seu nome completo' });
    const phone = h('input', { class: 'input', id: 'ph', type: 'tel', inputmode: 'tel', autocomplete: 'tel', maxlength: 16, required: true, placeholder: '(11) 91234-5678' });
    phone.addEventListener('input', () => {
      const d = phone.value.replace(/\D/g, '').slice(0, 11);
      phone.value = d.length > 7 ? `(${d.slice(0, 2)}) ${d.slice(2, d.length === 11 ? 7 : 6)}-${d.slice(d.length === 11 ? 7 : 6)}` : d.length > 2 ? `(${d.slice(0, 2)}) ${d.slice(2)}` : d;
    });
    const btn = h('button', { class: 'btn btn-dark', type: 'submit', style: { width: '100%' }, disabled: true }, 'Confirmar agendamento');
    const opts = services.map((s) => {
      const fits = s.duration_min <= S.maxMin;
      const radio = h('input', { type: 'radio', name: 'svc', value: s.id, disabled: !fits, onchange: () => { chosen = s; $$('.svc-opt').forEach((o) => o.classList.remove('sel')); lab.classList.add('sel'); btn.disabled = false; } });
      const lab = h('label', { class: 'svc-opt' + (fits ? '' : ' dis') }, radio, h('span', { class: 'n' }, h('b', {}, s.name), h('small', {}, `${s.duration_min} min` + (fits ? '' : ' — não cabe neste horário'))), h('span', { class: 'p' }, brl(s.price_cents)));
      return lab;
    });
    const form = h('form', { class: 'form-narrow', novalidate: true },
      h('div', { class: 'field' }, h('label', { for: 'nm' }, 'Seu nome'), name),
      h('div', { class: 'field' }, h('label', { for: 'ph' }, 'Telefone / WhatsApp'), phone),
      h('div', { class: 'lbl', style: { marginBottom: '10px' } }, 'Escolha o serviço'),
      h('div', { class: 'svc-pick', role: 'radiogroup' }, opts), err, btn);
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); err.hidden = true;
      if (!chosen) { err.textContent = 'Escolha o serviço desejado.'; err.hidden = false; return; }
      btn.disabled = true; btn.textContent = 'Confirmando…';
      try {
        const r = await api('POST', '/api/public/book', { barber_id: S.barber.id, service_id: chosen.id, date: S.date, time: S.time, name: name.value, phone: phone.value });
        stepDone(r.appointment);
      } catch (ex) {
        btn.disabled = false; btn.textContent = 'Confirmar agendamento';
        if (ex.status === 409) { toast(ex.message, 'err'); stepTime(); } else { err.textContent = ex.message; err.hidden = false; }
      }
    });
    view(back(stepTime, 'Trocar horário'), form);
  }

  // 5 — confirmação
  function stepDone(a) {
    header(4);
    const msg = `Olá! Acabei de agendar pelo site: ${a.service_name} com ${a.barber_name} em ${D.br(a.date)} às ${a.start}. Nome: ${a.client_name}.`;
    view(h('div', { class: 'done' },
      h('div', { class: 'done-head' }, h('div', { class: 'check' }, '✓'), h('h2', {}, 'Tudo certo!'), h('p', { style: { color: '#b4b4b0' } }, 'Seu horário está reservado.')),
      h('dl', {}, [['Cliente', a.client_name], ['Barbeiro', a.barber_name], ['Serviço', a.service_name], ['Data', D.long(a.date)], ['Horário', `${a.start} às ${a.end}`], ['Valor', brl(a.price_cents)]].map(([k, v]) => h('div', {}, h('dt', {}, k), h('dd', {}, v)))),
      h('div', { class: 'done-actions' },
        shop.whatsapp ? h('a', { class: 'btn btn-dark', href: waLink(shop.whatsapp, msg), target: '_blank', rel: 'noopener' }, icon('wa', 18), 'Avisar no WhatsApp') : null,
        h('a', { class: 'btn btn-ghost-dark', href: '/agendar' }, 'Fazer outro agendamento'),
        h('a', { class: 'btn btn-ghost-dark', href: '/' }, 'Voltar ao site'),
        h('p', { class: 'hint', style: { textAlign: 'center' } }, 'Para cancelar ou remarcar, fale com a barbearia' + (shop.whatsapp ? ' pelo WhatsApp.' : '.')))));
  }

  const pre = +new URLSearchParams(location.search).get('barber');
  const found = barbers.find((b) => b.id === pre);
  if (found) { S.barber = found; stepDate(); } else stepBarber();
})();
