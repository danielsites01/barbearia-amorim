'use strict';
// Utilidades compartilhadas (site público, agendamento e painel)
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function append(e, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    e.append(k.nodeType ? k : document.createTextNode(String(k)));
  }
}
// Cria elementos de forma segura (sempre textContent — sem risco de XSS)
function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  let value;
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'value') value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'selected') e[k] = !!v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  append(e, kids);
  if (value !== undefined) e.value = value;
  return e;
}
const clear = (e) => { e.replaceChildren(); return e; };

async function api(method, url, body) {
  const r = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
  let j = {};
  try { j = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(j.error || 'Erro inesperado. Tente novamente.'); e.status = r.status; throw e; }
  return j;
}

const brl = (c) => (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const pad2 = (n) => String(n).padStart(2, '0');
const WEEKDAYS = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
const WD_SHORT = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const MONTHS = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const MON_SHORT = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const D = {
  parse: (s) => new Date(s + 'T00:00:00Z'),
  str: (d) => d.toISOString().slice(0, 10),
  add: (s, n) => { const d = D.parse(s); d.setUTCDate(d.getUTCDate() + n); return D.str(d); },
  addMonths: (s, n) => { const d = D.parse(s.slice(0, 7) + '-01'); d.setUTCMonth(d.getUTCMonth() + n); return D.str(d); },
  dow: (s) => D.parse(s).getUTCDay(),
  mondayOf: (s) => D.add(s, -((D.dow(s) + 6) % 7)),
  monthStart: (s) => s.slice(0, 7) + '-01',
  monthEnd: (s) => D.add(D.addMonths(s, 1), -1),
  br: (s) => s.split('-').reverse().join('/'),
  long: (s) => { const d = D.parse(s); return `${WEEKDAYS[d.getUTCDay()]}, ${d.getUTCDate()} de ${MONTHS[d.getUTCMonth()]}`; },
  monthLabel: (s) => `${MONTHS[+s.slice(5, 7) - 1]} de ${s.slice(0, 4)}`,
};

function initials(name) {
  const p = name.trim().split(/\s+/);
  return ((p[0] || '')[0] + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase();
}
function avatar(person, cls = '') {
  if (person.photo) return h('img', { class: 'avatar ' + cls, src: person.photo, alt: person.name, loading: 'lazy' });
  return h('div', { class: 'avatar avatar-ph ' + cls, 'aria-label': person.name }, initials(person.name));
}

function toast(msg, kind = 'ok') {
  let box = $('#toasts');
  if (!box) { box = h('div', { id: 'toasts', 'aria-live': 'polite' }); document.body.append(box); }
  const t = h('div', { class: 'toast ' + kind }, msg);
  box.append(t);
  setTimeout(() => t.classList.add('out'), 3600);
  setTimeout(() => t.remove(), 4000);
}

function waLink(number, text) { return `https://wa.me/${number}${text ? '?text=' + encodeURIComponent(text) : ''}`; }

// Ícones (SVG inline, traço simples)
const ICON = {
  wa: 'M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm5.2 14c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.2-4.6-4-4.7-4.2-.1-.2-1.1-1.5-1.1-2.8s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.4 0 .6l-.4.6c-.1.2-.3.4-.1.7.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.4 2.4 1.5.3.1.5.1.6-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.6.4.1.1.1.7-.1 1.3z',
  ig: 'M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7zm5 3.5A4.5 4.5 0 1 1 7.5 12 4.5 4.5 0 0 1 12 7.5zm0 2A2.5 2.5 0 1 0 14.5 12 2.5 2.5 0 0 0 12 9.5zM17.3 6a1.2 1.2 0 1 1-1.2 1.2A1.2 1.2 0 0 1 17.3 6z',
  pin: 'M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 14.5 9 2.5 2.5 0 0 1 12 11.5z',
  phone: 'M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11 11 0 0 0 3.6.6 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1 11 11 0 0 0 .6 3.6 1 1 0 0 1-.25 1z',
  clock: 'M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm.5 5v5.2l4 2.4-.8 1.3-4.7-2.8V7z',
  scissors: 'M9.6 7.8A3.5 3.5 0 1 0 7.8 9.6L10 12l-2.2 2.4a3.5 3.5 0 1 0 1.8 1.8L12 14l7.5 7.5H22v-1L9.6 7.8zM6 8a1.5 1.5 0 1 1 1.5-1.5A1.5 1.5 0 0 1 6 8zm0 10a1.5 1.5 0 1 1 1.5-1.5A1.5 1.5 0 0 1 6 18zM14 10l2.5-2.5L22 3v1l-6 6-2-1z',
};
function icon(name, size = 20) {
  const ns = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(ns, 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size); s.setAttribute('height', size);
  s.setAttribute('fill', 'currentColor'); s.setAttribute('aria-hidden', 'true');
  const p = document.createElementNS(ns, 'path'); p.setAttribute('d', ICON[name]); s.append(p);
  return s;
}

// Animações de entrada suaves
function revealOnScroll() {
  const els = $$('.reveal:not(.in)');
  if (!('IntersectionObserver' in window)) return els.forEach((e) => e.classList.add('in'));
  const io = new IntersectionObserver((es) => es.forEach((x) => { if (x.isIntersecting) { x.target.classList.add('in'); io.unobserve(x.target); } }), { threshold: 0.12 });
  els.forEach((e) => io.observe(e));
}
