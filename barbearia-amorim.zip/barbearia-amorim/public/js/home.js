'use strict';
(async function () {
  // menu mobile
  const burger = $('#burger'), nav = $('#nav');
  burger.addEventListener('click', () => { const o = nav.classList.toggle('open'); burger.setAttribute('aria-expanded', o); });
  nav.addEventListener('click', (e) => { if (e.target.closest('a')) { nav.classList.remove('open'); burger.setAttribute('aria-expanded', false); } });

  let info;
  try { info = await api('GET', '/api/public/info'); } catch { toast('Não foi possível carregar os dados. Atualize a página.', 'err'); return; }
  const { shop, services, barbers, categories, gallery } = info;

  // hero
  const parts = shop.name.trim().split(/\s+/);
  const first = parts.length > 1 ? parts.slice(0, -1).join(' ') : shop.name, last = parts.length > 1 ? parts[parts.length - 1] : '';
  const h1 = clear($('#shopName')); h1.append(first + ' '); if (last) h1.append(h('span', {}, last));
  if (shop.tagline) $('#tagline').textContent = shop.tagline;
  $('#about').textContent = shop.about || '';
  const seen = new Set(), picks = [];
  for (const g of gallery) if (!seen.has(g.category) && picks.length < 3) { seen.add(g.category); picks.push(g); }
  const hp = $('#heroPhotos');
  picks.forEach((g) => hp.append(h('figure', {}, h('img', { src: g.file, alt: '', loading: 'eager' }))));
  if (!picks.length) hp.remove();

  // galeria
  const catName = Object.fromEntries(categories.map((c) => [c.slug, c.name]));
  const chips = $('#chips'), grid = $('#gallery');
  let current = 'all';
  const items = gallery.map((g, i) => {
    const b = h('button', { class: 'shot reveal', type: 'button', 'data-cat': g.category, 'aria-label': `Ampliar foto de ${catName[g.category] || 'corte'}` },
      h('img', { src: g.file, alt: `${catName[g.category] || 'Corte'} — ${shop.name}`, loading: 'lazy' }),
      h('span', { class: 'tagc' }, catName[g.category] || ''));
    b.addEventListener('click', () => openLb(b));
    grid.append(b); return b;
  });
  const setFilter = (slug) => {
    current = slug;
    $$('.chip', chips).forEach((c) => c.setAttribute('aria-pressed', c.dataset.slug === slug));
    items.forEach((b) => b.classList.toggle('hide', slug !== 'all' && b.dataset.cat !== slug));
  };
  if (!gallery.length) grid.replaceWith(h('div', { class: 'empty' }, 'Fotos em breve.'));
  else {
    [{ slug: 'all', name: 'Todos' }, ...categories].forEach((c) => chips.append(h('button', { class: 'chip', type: 'button', 'data-slug': c.slug, 'aria-pressed': c.slug === 'all', onclick: () => setFilter(c.slug) }, c.name)));
  }

  // lightbox
  const lb = $('#lb');
  let lbIdx = 0;
  const visible = () => items.filter((b) => !b.classList.contains('hide'));
  function showLb() { const v = visible(), b = v[lbIdx]; $('#lbImg').src = $('img', b).src; $('#lbImg').alt = $('img', b).alt; $('#lbCap').textContent = catName[b.dataset.cat] || ''; }
  function openLb(b) { lbIdx = visible().indexOf(b); showLb(); lb.showModal(); }
  const step = (d) => { const n = visible().length; lbIdx = (lbIdx + d + n) % n; showLb(); };
  $('#lbClose').addEventListener('click', () => lb.close());
  $('#lbPrev').addEventListener('click', () => step(-1));
  $('#lbNext').addEventListener('click', () => step(1));
  lb.addEventListener('click', (e) => { if (e.target === lb) lb.close(); });
  lb.addEventListener('keydown', (e) => { if (e.key === 'ArrowLeft') step(-1); if (e.key === 'ArrowRight') step(1); });

  // serviços
  const sg = $('#services');
  services.forEach((s, i) => sg.append(h('div', { class: 'svc reveal d' + (i % 3 + 1) }, h('h3', {}, s.name), h('div', { class: 'dur' }, icon('clock', 16), `${s.duration_min} min`), h('div', { class: 'price' }, brl(s.price_cents)))));
  if (!services.length) sg.append(h('div', { class: 'empty' }, 'Serviços em breve.'));

  // barbeiros
  const bg = $('#barbers');
  barbers.forEach((b, i) => bg.append(h('div', { class: 'bcard reveal d' + (i % 3 + 1) }, avatar(b), h('h3', {}, b.name), h('p', {}, b.bio || 'Barbeiro da equipe Amorim.'), h('a', { class: 'btn btn-light btn-sm', href: '/agendar?barber=' + b.id }, 'Agendar com ' + b.name.split(' ')[0]))));
  if (!barbers.length) bg.append(h('div', { class: 'empty', style: { color: '#b4b4b0', borderColor: '#2e2e2e' } }, 'Em breve nossos barbeiros estarão disponíveis para agendamento.'));

  // contato
  const ci = $('#cinfo');
  const item = (ic, label, value, href, ext) => ci.append(h(href ? 'a' : 'div', { class: 'citem', href, target: ext ? '_blank' : null, rel: ext ? 'noopener' : null }, h('span', { class: 'ico' }, icon(ic)), h('span', {}, h('small', {}, label), h('b', {}, value))));
  if (shop.address) item('pin', 'Endereço', shop.address, shop.maps_url || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(shop.address)}`, true);
  if (shop.whatsapp) item('wa', 'WhatsApp', fmtPhone(shop.whatsapp), waLink(shop.whatsapp, 'Olá! Vim pelo site da Barbearia Amorim.'), true);
  if (shop.instagram) item('ig', 'Instagram', '@' + shop.instagram, `https://instagram.com/${shop.instagram}`, true);
  if (shop.phone) item('phone', 'Telefone', shop.phone, 'tel:' + shop.phone.replace(/[^\d+]/g, ''));
  if (!ci.children.length) ci.append(h('div', { class: 'empty' }, 'Informações de contato em breve.'));
  const hl = $('#hours'); const t = new Date().getDay();
  const order = [1, 2, 3, 4, 5, 6, 0];
  order.forEach((d) => { const v = shop.hours[d]; hl.append(h('li', { class: d === t ? 'today' : '' }, h('span', {}, WEEKDAYS[d]), v ? h('span', {}, `${v[0]} – ${v[1]}`) : h('span', { class: 'closed' }, 'Fechado'))); });

  if (shop.whatsapp) { const f = $('#fab'); f.href = waLink(shop.whatsapp, 'Olá! Vim pelo site da Barbearia Amorim.'); f.append(icon('wa', 30)); f.hidden = false; }
  $('#copy').textContent = `© ${new Date().getFullYear()} ${shop.name}. Todos os direitos reservados.`;
  revealOnScroll();

  function fmtPhone(n) { const d = n.replace(/^55/, ''); return d.length === 11 ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}` : d.length === 10 ? `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}` : n; }
})();
