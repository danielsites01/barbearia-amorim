'use strict';
// Servidor da Barbearia Amorim — Node 22+, sem dependências externas.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const DB = require('./db');

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (m) => new HttpError(400, m);

// ---------- utilidades de data/hora (datas "YYYY-MM-DD", horas em minutos) ----------
const pad = (n) => String(n).padStart(2, '0');
const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && new Date(s + 'T00:00:00Z').toISOString().slice(0, 10) === s;
const isMonth = (s) => typeof s === 'string' && /^\d{4}-(0[1-9]|1[0-2])$/.test(s);
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const dow = (s) => new Date(s + 'T00:00:00Z').getUTCDay();
const daysBetween = (a, b) => Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 86400000);
const toMin = (hhmm) => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };
const fmt = (m) => pad(Math.floor(m / 60)) + ':' + pad(m % 60);
const isHHMM = (s) => typeof s === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
function nowIn(tz) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date());
  const g = (t) => parts.find((p) => p.type === t).value;
  return { date: `${g('year')}-${g('month')}-${g('day')}`, min: +g('hour') * 60 + +g('minute') };
}

function createApp({ dbFile, publicDir, uploadsDir }) {
  const db = DB.open(dbFile);
  fs.mkdirSync(uploadsDir, { recursive: true });

  // ---------- configurações ----------
  const getSettings = () => {
    const s = {};
    for (const r of db.prepare('SELECT key,value FROM settings').all()) s[r.key] = r.value;
    s.hours = JSON.parse(s.hours);
    s.slot_minutes = +s.slot_minutes; s.advance_days = +s.advance_days; s.min_lead_minutes = +s.min_lead_minutes;
    return s;
  };
  const today = () => nowIn(getSettings().timezone);

  const tx = (fn) => {
    db.exec('BEGIN IMMEDIATE');
    try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
  };

  // ---------- disponibilidade (fonte única de verdade para site e painel) ----------
  // Retorna os horários de início livres com o tempo contínuo disponível (maxMin).
  function slotsInfo(barberId, date, { staff = false } = {}) {
    const S = getSettings();
    const barber = db.prepare("SELECT id,work_days,active FROM users WHERE id=? AND role='barber'").get(barberId);
    if (!barber || !barber.active) return [];
    if (!JSON.parse(barber.work_days).includes(dow(date))) return [];
    const hrs = S.hours[dow(date)];
    if (!hrs) return [];
    const open = toMin(hrs[0]), close = toMin(hrs[1]);
    const busy = [];
    for (const a of db.prepare("SELECT start_min s,end_min e FROM appointments WHERE barber_id=? AND date=? AND status IN ('agendado','concluido')").all(barberId, date)) busy.push([a.s, a.e]);
    for (const b of db.prepare('SELECT start_min s,end_min e FROM blocks WHERE date=? AND (barber_id IS NULL OR barber_id=?)').all(date, barberId)) {
      busy.push([b.s ?? 0, b.e ?? 1440]);
    }
    const minDur = db.prepare('SELECT MIN(duration_min) m FROM services WHERE active=1').get().m || S.slot_minutes;
    const now = nowIn(S.timezone);
    let earliest = 0;
    if (!staff) {
      if (date < now.date || date > addDays(now.date, S.advance_days)) return [];
      if (date === now.date) earliest = now.min + S.min_lead_minutes;
    }
    const out = [];
    for (let s = open; s < close; s += S.slot_minutes) {
      if (s < earliest) continue;
      if (busy.some(([bs, be]) => s >= bs && s < be)) continue;
      let next = close;
      for (const [bs] of busy) if (bs > s && bs < next) next = bs;
      const maxMin = next - s;
      if (maxMin >= minDur) out.push({ start: s, maxMin });
    }
    return out;
  }

  function createAppointment({ barberId, serviceId, date, start, name, phone, source }, { staff = false } = {}) {
    const svc = db.prepare('SELECT * FROM services WHERE id=? AND active=1').get(serviceId);
    if (!svc) throw bad('Serviço inválido.');
    return tx(() => {
      const slot = slotsInfo(barberId, date, { staff }).find((x) => x.start === start);
      if (!slot) throw new HttpError(409, 'Este horário não está mais disponível. Escolha outro.');
      if (slot.maxMin < svc.duration_min) throw new HttpError(409, 'Este serviço não cabe neste horário. Escolha outro horário ou serviço.');
      try {
        const r = db.prepare(`INSERT INTO appointments(barber_id,service_id,service_name,price_cents,client_name,client_phone,date,start_min,end_min,source)
          VALUES (?,?,?,?,?,?,?,?,?,?)`).run(barberId, svc.id, svc.name, svc.price_cents, name, phone, date, start, start + svc.duration_min, source);
        return Number(r.lastInsertRowid);
      } catch (e) {
        if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'Este horário acabou de ser reservado. Escolha outro.');
        throw e;
      }
    });
  }

  // ---------- validação de entrada ----------
  const cleanStr = (v, min, max, label) => {
    if (typeof v !== 'string') throw bad(`${label} inválido.`);
    const s = v.replace(/\s+/g, ' ').trim();
    if (s.length < min || s.length > max) throw bad(`${label} deve ter entre ${min} e ${max} caracteres.`);
    return s;
  };
  const cleanPhone = (v, required = true) => {
    let d = String(v ?? '').replace(/\D/g, '');
    if (!d && !required) return '';
    if (d.length >= 12 && d.startsWith('55')) d = d.slice(2);
    if (d.length < 10 || d.length > 11) throw bad('Telefone inválido. Use DDD + número.');
    return d;
  };
  const intIn = (v, min, max, label) => { const n = Number(v); if (!Number.isInteger(n) || n < min || n > max) throw bad(`${label} inválido.`); return n; };
  const PAY = ['dinheiro', 'pix', 'cartao_debito', 'cartao_credito'];

  // ---------- sessões e segurança ----------
  const SESSION_TTL = 12 * 3600 * 1000;
  const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
  const attempts = new Map(); // limitador de tentativas de login
  const bookings = new Map(); // limitador de agendamentos por IP
  const hit = (map, key, limit, windowMs) => {
    const now = Date.now(); const e = map.get(key);
    if (!e || e.reset < now) { map.set(key, { n: 1, reset: now + windowMs }); return true; }
    e.n++; return e.n <= limit;
  };
  setInterval(() => {
    const now = Date.now();
    for (const m of [attempts, bookings]) for (const [k, v] of m) if (v.reset < now) m.delete(k);
    db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now);
  }, 600000).unref();
  const DUMMY_HASH = DB.hashPassword('dummy-password-for-timing');

  const parseCookies = (h) => Object.fromEntries((h || '').split(';').map((c) => c.trim().split('=')).filter((p) => p[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
  function userFromReq(req) {
    const t = parseCookies(req.headers.cookie).amorim_session;
    if (!t) return null;
    const row = db.prepare(`SELECT u.id,u.name,u.username,u.role,u.commission_pct FROM sessions s JOIN users u ON u.id=s.user_id
      WHERE s.token_hash=? AND s.expires_at>? AND u.active=1`).get(sha(t), Date.now());
    return row || null;
  }
  const clientIp = (req) => (process.env.TRUST_PROXY ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() : '') || req.socket.remoteAddress || '';

  // ---------- consultas compartilhadas ----------
  const shapeAppt = (a) => ({
    id: a.id, barber_id: a.barber_id, barber_name: a.barber_name, date: a.date,
    start: fmt(a.start_min), end: fmt(a.end_min), client_name: a.client_name, client_phone: a.client_phone,
    service_name: a.service_name, price_cents: a.price_cents, status: a.status, source: a.source,
    commission_cents: a.commission_cents ?? null, shop_cents: a.shop_cents ?? null, payment_method: a.payment_method ?? null,
  });
  const APPT_SQL = `SELECT a.*, u.name barber_name, t.commission_cents, t.shop_cents, t.payment_method
    FROM appointments a JOIN users u ON u.id=a.barber_id LEFT JOIN transactions t ON t.appointment_id=a.id`;
  const scope = (ctx, requested) => (ctx.user.role === 'barber' ? ctx.user.id : requested ? intIn(requested, 1, 1e9, 'Barbeiro') : null);
  const range = (q) => {
    if (!isDate(q.from) || !isDate(q.to) || q.from > q.to) throw bad('Período inválido.');
    if (daysBetween(q.from, q.to) > 3700) throw bad('Período muito longo.');
    return [q.from, q.to];
  };

  // ---------- rotas ----------
  const routes = [];
  const route = (method, pattern, auth, handler) => {
    const keys = [];
    const rx = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, rx, keys, auth, handler });
  };

  // --- público ---
  route('GET', '/api/public/info', null, () => {
    const S = getSettings();
    const shop = { name: S.shop_name, tagline: S.tagline, about: S.about, address: S.address, phone: S.phone, whatsapp: S.whatsapp, instagram: S.instagram, maps_url: S.maps_url, hours: S.hours };
    const services = db.prepare('SELECT id,name,price_cents,duration_min FROM services WHERE active=1 ORDER BY price_cents, name').all();
    const barbers = db.prepare("SELECT id,name,bio,photo FROM users WHERE role='barber' AND active=1 ORDER BY name").all();
    const categories = db.prepare('SELECT slug,name FROM categories WHERE slug IN (SELECT DISTINCT category FROM gallery) ORDER BY sort').all();
    const gallery = db.prepare('SELECT id,category,file,caption FROM gallery ORDER BY sort,id').all();
    return { shop, services, barbers, categories, gallery };
  });

  route('GET', '/api/public/days', null, (ctx) => {
    const { barber, month } = ctx.query;
    if (!isMonth(month)) throw bad('Mês inválido.');
    const b = intIn(barber, 1, 1e9, 'Barbeiro');
    const days = {}; const first = month + '-01';
    for (let i = 0; i < 31; i++) {
      const d = addDays(first, i);
      if (d.slice(0, 7) !== month) break;
      const n = slotsInfo(b, d).length;
      if (n) days[d] = n;
    }
    const t = today();
    return { days, today: t.date, max_date: addDays(t.date, getSettings().advance_days) };
  });

  route('GET', '/api/public/slots', null, (ctx) => {
    const { barber, date } = ctx.query;
    if (!isDate(date)) throw bad('Data inválida.');
    const slots = slotsInfo(intIn(barber, 1, 1e9, 'Barbeiro'), date).map((s) => ({ time: fmt(s.start), max_min: s.maxMin }));
    return { slots };
  });

  route('POST', '/api/public/book', null, (ctx) => {
    if (!hit(bookings, clientIp(ctx.req), Number(process.env.BOOK_LIMIT) || 12, 3600000)) throw new HttpError(429, 'Muitas tentativas. Tente novamente mais tarde.');
    const b = ctx.body;
    if (!isDate(b.date) || !isHHMM(b.time)) throw bad('Data ou horário inválido.');
    const name = cleanStr(b.name, 2, 80, 'Nome');
    const phone = cleanPhone(b.phone);
    const barberId = intIn(b.barber_id, 1, 1e9, 'Barbeiro');
    const id = createAppointment({ barberId, serviceId: intIn(b.service_id, 1, 1e9, 'Serviço'), date: b.date, start: toMin(b.time), name, phone, source: 'site' });
    const a = db.prepare(APPT_SQL + ' WHERE a.id=?').get(id);
    return { ok: true, appointment: { id: a.id, barber_name: a.barber_name, service_name: a.service_name, price_cents: a.price_cents, date: a.date, start: fmt(a.start_min), end: fmt(a.end_min), client_name: a.client_name } };
  });

  // --- autenticação ---
  route('POST', '/api/auth/login', null, (ctx) => {
    const username = String(ctx.body.username || '').trim().slice(0, 60);
    const password = String(ctx.body.password || '').slice(0, 200);
    const key = clientIp(ctx.req) + '|' + username.toLowerCase();
    const e = attempts.get(key);
    if (e && e.reset > Date.now() && e.n >= 8) throw new HttpError(429, 'Muitas tentativas. Aguarde alguns minutos.');
    const u = db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(username);
    const ok = DB.verifyPassword(password, u ? u.pass_hash : DUMMY_HASH) && u;
    if (!ok) { hit(attempts, key, 1e9, 15 * 60000); throw new HttpError(401, 'Usuário ou senha incorretos.'); }
    attempts.delete(key);
    const token = crypto.randomBytes(32).toString('base64url');
    db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES (?,?,?)').run(sha(token), u.id, Date.now() + SESSION_TTL);
    const secure = process.env.COOKIE_SECURE === '1' || ctx.req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
    ctx.setCookie = `amorim_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_TTL / 1000}${secure}`;
    return { user: { id: u.id, name: u.name, role: u.role } };
  });
  route('POST', '/api/auth/logout', null, (ctx) => {
    const t = parseCookies(ctx.req.headers.cookie).amorim_session;
    if (t) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(t));
    ctx.setCookie = 'amorim_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0';
    return { ok: true };
  });
  route('GET', '/api/auth/me', null, (ctx) => {
    const u = userFromReq(ctx.req);
    return { user: u ? { id: u.id, name: u.name, role: u.role, commission_pct: u.commission_pct } : null, today: today().date };
  });
  route('POST', '/api/auth/password', 'staff', (ctx) => {
    const cur = db.prepare('SELECT pass_hash FROM users WHERE id=?').get(ctx.user.id);
    if (!DB.verifyPassword(String(ctx.body.current || ''), cur.pass_hash)) throw new HttpError(400, 'Senha atual incorreta.');
    const np = String(ctx.body.new || '');
    if (np.length < 8 || np.length > 100) throw bad('A nova senha deve ter ao menos 8 caracteres.');
    db.prepare('UPDATE users SET pass_hash=? WHERE id=?').run(DB.hashPassword(np), ctx.user.id);
    const t = parseCookies(ctx.req.headers.cookie).amorim_session;
    db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash<>?').run(ctx.user.id, sha(t)); // encerra outras sessões
    return { ok: true };
  });

  // --- agenda (barbeiro: somente a sua; admin: todas ou filtrada) ---
  route('GET', '/api/agenda', 'staff', (ctx) => {
    const [from, to] = range(ctx.query);
    if (daysBetween(from, to) > 400) throw bad('Período muito longo para a agenda.');
    const b = scope(ctx, ctx.query.barber);
    const rows = db.prepare(APPT_SQL + ` WHERE a.date BETWEEN ? AND ? ${b ? 'AND a.barber_id=?' : ''} ORDER BY a.date, a.start_min, a.id`).all(...(b ? [from, to, b] : [from, to]));
    const blocks = db.prepare(`SELECT id,barber_id,date,start_min,end_min,reason FROM blocks WHERE date BETWEEN ? AND ? ${b ? 'AND (barber_id IS NULL OR barber_id=?)' : ''} ORDER BY date`).all(...(b ? [from, to, b] : [from, to]))
      .map((x) => ({ ...x, start: x.start_min == null ? null : fmt(x.start_min), end: x.end_min == null ? null : fmt(x.end_min) }));
    return { appointments: rows.map(shapeAppt), blocks, today: today().date };
  });

  route('GET', '/api/slots', 'staff', (ctx) => { // horários livres para lançamento manual
    const b = ctx.user.role === 'barber' ? ctx.user.id : intIn(ctx.query.barber, 1, 1e9, 'Barbeiro');
    if (!isDate(ctx.query.date)) throw bad('Data inválida.');
    return { slots: slotsInfo(b, ctx.query.date, { staff: true }).map((s) => ({ time: fmt(s.start), max_min: s.maxMin })) };
  });

  route('POST', '/api/appointments', 'staff', (ctx) => { // lançamento manual (cliente presencial / encaixe)
    const b = ctx.body;
    if (!isDate(b.date) || !isHHMM(b.time)) throw bad('Data ou horário inválido.');
    if (b.date < addDays(today().date, -62)) throw bad('Data muito antiga.');
    const barberId = ctx.user.role === 'barber' ? ctx.user.id : intIn(b.barber_id, 1, 1e9, 'Barbeiro');
    const id = createAppointment({ barberId, serviceId: intIn(b.service_id, 1, 1e9, 'Serviço'), date: b.date, start: toMin(b.time), name: cleanStr(b.client_name, 2, 80, 'Nome'), phone: cleanPhone(b.client_phone, false), source: 'balcao' }, { staff: true });
    return { ok: true, appointment: shapeAppt(db.prepare(APPT_SQL + ' WHERE a.id=?').get(id)) };
  });

  route('PATCH', '/api/appointments/:id/status', 'staff', (ctx) => {
    const status = ctx.body.status;
    if (!['agendado', 'concluido', 'cancelado', 'faltou'].includes(status)) throw bad('Situação inválida.');
    const result = tx(() => {
      const a = db.prepare('SELECT * FROM appointments WHERE id=?').get(intIn(ctx.params.id, 1, 1e12, 'Atendimento'));
      if (!a || (ctx.user.role === 'barber' && a.barber_id !== ctx.user.id)) throw new HttpError(404, 'Atendimento não encontrado.');
      if (a.status === status) {
        if (status === 'concluido') return a.id; // idempotente: nunca contabiliza duas vezes
        return a.id;
      }
      if (a.status === 'concluido' && ctx.user.role !== 'admin') throw new HttpError(403, 'Atendimento concluído só pode ser reaberto pelo proprietário.');
      const t = today();
      if ((status === 'concluido' || status === 'faltou') && a.date > t.date) throw bad('Não é possível concluir ou marcar falta em atendimento futuro.');
      if (status === 'concluido') {
        const method = ctx.body.payment_method;
        if (!PAY.includes(method)) throw bad('Informe a forma de pagamento para concluir.');
        const barber = db.prepare('SELECT commission_pct FROM users WHERE id=?').get(a.barber_id);
        const commission = Math.floor((a.price_cents * barber.commission_pct) / 100);
        db.prepare('UPDATE appointments SET status=? WHERE id=?').run(status, a.id);
        db.prepare(`INSERT INTO transactions(appointment_id,barber_id,date,gross_cents,commission_pct,commission_cents,shop_cents,payment_method)
          VALUES (?,?,?,?,?,?,?,?)`).run(a.id, a.barber_id, a.date, a.price_cents, barber.commission_pct, commission, a.price_cents - commission, method);
        return a.id;
      }
      // saindo de "concluído" (admin): estorna o lançamento financeiro
      if (a.status === 'concluido') db.prepare('DELETE FROM transactions WHERE appointment_id=?').run(a.id);
      if (status === 'agendado' && db.prepare(`SELECT 1 FROM appointments WHERE barber_id=? AND date=? AND id<>? AND status IN ('agendado','concluido') AND start_min<? AND end_min>?`).get(a.barber_id, a.date, a.id, a.end_min, a.start_min))
        throw new HttpError(409, 'Esse horário já foi ocupado por outro agendamento.');
      try { db.prepare('UPDATE appointments SET status=? WHERE id=?').run(status, a.id); }
      catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'Esse horário já foi ocupado por outro agendamento.'); throw e; }
      return a.id;
    });
    return { ok: true, appointment: shapeAppt(db.prepare(APPT_SQL + ' WHERE a.id=?').get(result)) };
  });

  // --- financeiro / dashboards ---
  route('GET', '/api/stats', 'staff', (ctx) => {
    const [from, to] = range(ctx.query);
    const b = scope(ctx, ctx.query.barber);
    const W = b ? 'AND barber_id=?' : ''; const P = b ? [from, to, b] : [from, to];
    const totals = db.prepare(`SELECT COALESCE(SUM(gross_cents),0) gross, COALESCE(SUM(commission_cents),0) commission, COALESCE(SUM(shop_cents),0) shop, COUNT(*) count
      FROM transactions WHERE date BETWEEN ? AND ? ${W}`).get(...P);
    const monthly = daysBetween(from, to) > 62;
    const series = db.prepare(`SELECT ${monthly ? 'substr(date,1,7)' : 'date'} k, SUM(gross_cents) gross, SUM(commission_cents) commission, SUM(shop_cents) shop, COUNT(*) count
      FROM transactions WHERE date BETWEEN ? AND ? ${W} GROUP BY k ORDER BY k`).all(...P);
    const byStatus = {};
    for (const r of db.prepare(`SELECT status, COUNT(*) n FROM appointments WHERE date BETWEEN ? AND ? ${W} GROUP BY status`).all(...P)) byStatus[r.status] = r.n;
    const t = today();
    const upcoming = db.prepare(`SELECT COUNT(*) n FROM appointments WHERE status='agendado' AND (date>? OR (date=? AND start_min>=?)) ${W}`).get(...[t.date, t.date, t.min, ...(b ? [b] : [])]).n;
    const byService = db.prepare(`SELECT a.service_name name, COUNT(*) count, SUM(t.gross_cents) gross FROM transactions t JOIN appointments a ON a.id=t.appointment_id
      WHERE t.date BETWEEN ? AND ? ${b ? 'AND t.barber_id=?' : ''} GROUP BY a.service_name ORDER BY gross DESC`).all(...P);
    return { totals, bucket: monthly ? 'month' : 'day', series, by_status: byStatus, upcoming, by_service: byService };
  });

  route('GET', '/api/stats/months', 'staff', (ctx) => {
    const y = intIn(ctx.query.year, 2000, 2100, 'Ano');
    const b = scope(ctx, ctx.query.barber);
    const rows = db.prepare(`SELECT substr(date,1,7) k, SUM(gross_cents) gross, SUM(commission_cents) commission, SUM(shop_cents) shop, COUNT(*) count
      FROM transactions WHERE date BETWEEN ? AND ? ${b ? 'AND barber_id=?' : ''} GROUP BY k`).all(...[`${y}-01-01`, `${y}-12-31`, ...(b ? [b] : [])]);
    const map = Object.fromEntries(rows.map((r) => [r.k, r]));
    return { year: y, months: Array.from({ length: 12 }, (_, i) => { const k = `${y}-${pad(i + 1)}`; const r = map[k] || {}; return { month: k, gross: r.gross || 0, commission: r.commission || 0, shop: r.shop || 0, count: r.count || 0 }; }) };
  });

  route('GET', '/api/history', 'staff', (ctx) => {
    const [from, to] = range(ctx.query);
    const b = scope(ctx, ctx.query.barber);
    const limit = Math.min(Math.max(+ctx.query.limit || 50, 1), 200), offset = Math.max(+ctx.query.offset || 0, 0);
    const P = b ? [from, to, b] : [from, to];
    const total = db.prepare(`SELECT COUNT(*) n FROM transactions WHERE date BETWEEN ? AND ? ${b ? 'AND barber_id=?' : ''}`).get(...P).n;
    const rows = db.prepare(`SELECT t.id, t.date, a.start_min, a.client_name, a.service_name, u.name barber_name, t.gross_cents, t.commission_pct, t.commission_cents, t.shop_cents, t.payment_method, t.paid_at
      FROM transactions t JOIN appointments a ON a.id=t.appointment_id JOIN users u ON u.id=t.barber_id
      WHERE t.date BETWEEN ? AND ? ${b ? 'AND t.barber_id=?' : ''} ORDER BY t.date DESC, a.start_min DESC LIMIT ${limit} OFFSET ${offset}`).all(...P)
      .map((r) => ({ ...r, start: fmt(r.start_min) }));
    return { total, rows };
  });

  // --- administração (somente proprietário) ---
  const A = 'admin';
  route('GET', '/api/admin/ranking', A, (ctx) => {
    const [from, to] = range(ctx.query);
    const rows = db.prepare(`SELECT u.id, u.name, u.photo, COALESCE(SUM(t.gross_cents),0) gross, COALESCE(SUM(t.commission_cents),0) commission, COALESCE(SUM(t.shop_cents),0) shop, COUNT(t.id) count
      FROM users u LEFT JOIN transactions t ON t.barber_id=u.id AND t.date BETWEEN ? AND ?
      WHERE u.role='barber' AND (u.active=1 OR t.id IS NOT NULL) GROUP BY u.id ORDER BY gross DESC, u.name`).all(from, to);
    return { ranking: rows };
  });

  const reportRows = (q) => {
    const [from, to] = range(q);
    const by = { day: 'date', month: 'substr(date,1,7)', year: 'substr(date,1,4)' }[q.by || 'day'];
    if (!by) throw bad('Agrupamento inválido.');
    const b = q.barber ? intIn(q.barber, 1, 1e9, 'Barbeiro') : null;
    return db.prepare(`SELECT ${by} period, u.id barber_id, u.name barber_name, COUNT(*) count, SUM(t.gross_cents) gross, SUM(t.commission_cents) commission, SUM(t.shop_cents) shop
      FROM transactions t JOIN users u ON u.id=t.barber_id WHERE t.date BETWEEN ? AND ? ${b ? 'AND t.barber_id=?' : ''}
      GROUP BY period, u.id ORDER BY period DESC, u.name`).all(...(b ? [from, to, b] : [from, to]));
  };
  route('GET', '/api/admin/report', A, (ctx) => {
    const rows = reportRows(ctx.query);
    const totals = rows.reduce((a, r) => ({ count: a.count + r.count, gross: a.gross + r.gross, commission: a.commission + r.commission, shop: a.shop + r.shop }), { count: 0, gross: 0, commission: 0, shop: 0 });
    return { rows, totals };
  });
  route('GET', '/api/admin/report.csv', A, (ctx) => {
    const money = (c) => (c / 100).toFixed(2).replace('.', ',');
    const lines = [['Período', 'Barbeiro', 'Atendimentos', 'Faturamento bruto (R$)', 'Comissão do barbeiro (R$)', 'Parte da barbearia (R$)']];
    for (const r of reportRows(ctx.query)) lines.push([r.period, r.barber_name, r.count, money(r.gross), money(r.commission), money(r.shop)]);
    ctx.raw = { type: 'text/csv; charset=utf-8', filename: 'relatorio-amorim.csv', body: '﻿' + lines.map((l) => l.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(';')).join('\r\n') };
  });

  const barberOut = (u) => ({ id: u.id, name: u.name, username: u.username, role: u.role, bio: u.bio, photo: u.photo, work_days: JSON.parse(u.work_days), commission_pct: u.commission_pct, active: !!u.active });
  const parseDays = (v) => { if (!Array.isArray(v) || v.some((d) => !Number.isInteger(d) || d < 0 || d > 6)) throw bad('Dias de trabalho inválidos.'); return JSON.stringify([...new Set(v)].sort()); };
  const cleanUrl = (v) => { v = String(v || ''); if (v && !/^\/(uploads|img)\/[\w./-]+$/.test(v)) throw bad('Imagem inválida.'); return v; };
  const cleanUsername = (v) => { v = String(v || '').trim(); if (!/^[a-zA-Z0-9._-]{3,30}$/.test(v)) throw bad('Login deve ter 3–30 caracteres (letras, números, ponto, hífen ou _).'); return v; };

  route('GET', '/api/admin/barbers', A, () => ({ barbers: db.prepare("SELECT * FROM users WHERE role='barber' ORDER BY active DESC, name").all().map(barberOut) }));
  route('POST', '/api/admin/barbers', A, (ctx) => {
    const b = ctx.body; const pw = String(b.password || '');
    if (pw.length < 8 || pw.length > 100) throw bad('A senha deve ter ao menos 8 caracteres.');
    try {
      const r = db.prepare("INSERT INTO users(name,username,pass_hash,role,bio,photo,work_days,commission_pct) VALUES (?,?,?,'barber',?,?,?,?)")
        .run(cleanStr(b.name, 2, 60, 'Nome'), cleanUsername(b.username), DB.hashPassword(pw), cleanStr(b.bio ?? '', 0, 300, 'Apresentação'), cleanUrl(b.photo), parseDays(b.work_days ?? [1, 2, 3, 4, 5, 6]), intIn(b.commission_pct ?? 50, 0, 100, 'Comissão'));
      return { barber: barberOut(db.prepare('SELECT * FROM users WHERE id=?').get(Number(r.lastInsertRowid))) };
    } catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'Já existe um usuário com esse login.'); throw e; }
  });
  route('PUT', '/api/admin/barbers/:id', A, (ctx) => {
    const id = intIn(ctx.params.id, 1, 1e9, 'Barbeiro'); const b = ctx.body;
    const u = db.prepare("SELECT * FROM users WHERE id=? AND role='barber'").get(id);
    if (!u) throw new HttpError(404, 'Barbeiro não encontrado.');
    try {
      db.prepare('UPDATE users SET name=?,username=?,bio=?,photo=?,work_days=?,commission_pct=?,active=? WHERE id=?')
        .run(cleanStr(b.name, 2, 60, 'Nome'), cleanUsername(b.username), cleanStr(b.bio ?? '', 0, 300, 'Apresentação'), cleanUrl(b.photo), parseDays(b.work_days), intIn(b.commission_pct, 0, 100, 'Comissão'), b.active ? 1 : 0, id);
    } catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'Já existe um usuário com esse login.'); throw e; }
    if (b.password) {
      if (String(b.password).length < 8) throw bad('A senha deve ter ao menos 8 caracteres.');
      db.prepare('UPDATE users SET pass_hash=? WHERE id=?').run(DB.hashPassword(String(b.password)), id);
      db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
    }
    if (!b.active) db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
    const future = db.prepare("SELECT COUNT(*) n FROM appointments WHERE barber_id=? AND status='agendado' AND date>=?").get(id, today().date).n;
    return { barber: barberOut(db.prepare('SELECT * FROM users WHERE id=?').get(id)), future_appointments: future };
  });

  route('GET', '/api/admin/services', A, () => ({ services: db.prepare('SELECT id,name,price_cents,duration_min,active FROM services ORDER BY active DESC, price_cents, name').all() }));
  const svcArgs = (b) => [cleanStr(b.name, 2, 60, 'Nome'), intIn(b.price_cents, 0, 1000000, 'Preço'), intIn(b.duration_min, 5, 240, 'Duração'), b.active === false ? 0 : 1];
  route('POST', '/api/admin/services', A, (ctx) => ({ id: Number(db.prepare('INSERT INTO services(name,price_cents,duration_min,active) VALUES (?,?,?,?)').run(...svcArgs(ctx.body)).lastInsertRowid) }));
  route('PUT', '/api/admin/services/:id', A, (ctx) => { db.prepare('UPDATE services SET name=?,price_cents=?,duration_min=?,active=? WHERE id=?').run(...svcArgs(ctx.body), intIn(ctx.params.id, 1, 1e9, 'Serviço')); return { ok: true }; });
  route('DELETE', '/api/admin/services/:id', A, (ctx) => { db.prepare('UPDATE services SET active=0 WHERE id=?').run(intIn(ctx.params.id, 1, 1e9, 'Serviço')); return { ok: true }; });

  route('GET', '/api/admin/blocks', A, (ctx) => {
    const from = isDate(ctx.query.from) ? ctx.query.from : today().date;
    const rows = db.prepare(`SELECT b.id,b.barber_id,u.name barber_name,b.date,b.start_min,b.end_min,b.reason FROM blocks b LEFT JOIN users u ON u.id=b.barber_id WHERE b.date>=? ORDER BY b.date,b.start_min`).all(from)
      .map((x) => ({ ...x, start: x.start_min == null ? null : fmt(x.start_min), end: x.end_min == null ? null : fmt(x.end_min) }));
    return { blocks: rows };
  });
  route('POST', '/api/admin/blocks', A, (ctx) => {
    const b = ctx.body;
    if (!isDate(b.date)) throw bad('Data inválida.');
    const barber = b.barber_id ? intIn(b.barber_id, 1, 1e9, 'Barbeiro') : null;
    let s = null, e = null;
    if (b.start || b.end) {
      if (!isHHMM(b.start) || !isHHMM(b.end) || toMin(b.start) >= toMin(b.end)) throw bad('Horário de bloqueio inválido.');
      s = toMin(b.start); e = toMin(b.end);
    }
    const r = db.prepare('INSERT INTO blocks(barber_id,date,start_min,end_min,reason) VALUES (?,?,?,?,?)').run(barber, b.date, s, e, cleanStr(b.reason ?? '', 0, 120, 'Motivo'));
    const conflicts = db.prepare(`SELECT COUNT(*) n FROM appointments WHERE date=? AND status='agendado' ${barber ? 'AND barber_id=?' : ''} AND start_min < ? AND end_min > ?`).get(...[b.date, ...(barber ? [barber] : []), e ?? 1440, s ?? 0]).n;
    return { id: Number(r.lastInsertRowid), conflicts };
  });
  route('DELETE', '/api/admin/blocks/:id', A, (ctx) => { db.prepare('DELETE FROM blocks WHERE id=?').run(intIn(ctx.params.id, 1, 1e12, 'Bloqueio')); return { ok: true }; });

  route('GET', '/api/admin/settings', A, () => ({ settings: getSettings(), categories: db.prepare('SELECT slug,name FROM categories ORDER BY sort').all() }));
  route('PUT', '/api/admin/settings', A, (ctx) => {
    const b = ctx.body; const out = {};
    if ('shop_name' in b) out.shop_name = cleanStr(b.shop_name, 2, 80, 'Nome');
    if ('tagline' in b) out.tagline = cleanStr(b.tagline, 0, 160, 'Frase de destaque');
    if ('about' in b) out.about = cleanStr(b.about, 0, 1200, 'Apresentação');
    if ('address' in b) out.address = cleanStr(b.address, 0, 200, 'Endereço');
    if ('phone' in b) out.phone = cleanStr(b.phone, 0, 30, 'Telefone');
    if ('whatsapp' in b) { let d = String(b.whatsapp).replace(/\D/g, ''); if (d && d.length <= 11) d = '55' + d; if (d && (d.length < 12 || d.length > 13)) throw bad('WhatsApp inválido. Use DDD + número.'); out.whatsapp = d; }
    if ('instagram' in b) { const h = String(b.instagram).trim().replace(/^https?:\/\/(www\.)?instagram\.com\//i, '').replace(/^@/, '').replace(/\/.*$/, ''); if (h && !/^[A-Za-z0-9._]{1,30}$/.test(h)) throw bad('Instagram inválido.'); out.instagram = h; }
    if ('maps_url' in b) { const u = String(b.maps_url).trim(); if (u && !/^https:\/\/[^\s]+$/.test(u)) throw bad('Link do mapa deve começar com https://'); out.maps_url = u; }
    if ('slot_minutes' in b) { const n = intIn(b.slot_minutes, 5, 120, 'Intervalo'); if (![10, 15, 20, 30, 40, 45, 60].includes(n)) throw bad('Intervalo inválido.'); out.slot_minutes = String(n); }
    if ('advance_days' in b) out.advance_days = String(intIn(b.advance_days, 1, 365, 'Antecedência máxima'));
    if ('min_lead_minutes' in b) out.min_lead_minutes = String(intIn(b.min_lead_minutes, 0, 1440, 'Antecedência mínima'));
    if ('hours' in b) {
      const h = {};
      for (let d = 0; d < 7; d++) {
        const v = b.hours?.[d];
        if (v == null) { h[d] = null; continue; }
        if (!Array.isArray(v) || !isHHMM(v[0]) || !isHHMM(v[1]) || toMin(v[0]) >= toMin(v[1])) throw bad('Horário de funcionamento inválido.');
        h[d] = [v[0], v[1]];
      }
      out.hours = JSON.stringify(h);
    }
    tx(() => { for (const [k, v] of Object.entries(out)) db.prepare('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, v); });
    return { settings: getSettings() };
  });

  route('GET', '/api/admin/gallery', A, () => ({ gallery: db.prepare('SELECT id,category,file,caption FROM gallery ORDER BY sort,id').all(), categories: db.prepare('SELECT slug,name FROM categories ORDER BY sort').all() }));
  route('POST', '/api/admin/gallery', A, (ctx) => {
    const b = ctx.body;
    if (!db.prepare('SELECT 1 FROM categories WHERE slug=?').get(b.category)) throw bad('Categoria inválida.');
    const file = cleanUrl(b.file); if (!file) throw bad('Imagem obrigatória.');
    const max = db.prepare('SELECT COALESCE(MAX(sort),0)+1 n FROM gallery').get().n;
    return { id: Number(db.prepare('INSERT INTO gallery(category,file,caption,sort) VALUES (?,?,?,?)').run(b.category, file, cleanStr(b.caption ?? '', 0, 80, 'Legenda'), max).lastInsertRowid) };
  });
  route('DELETE', '/api/admin/gallery/:id', A, (ctx) => {
    const g = db.prepare('SELECT file FROM gallery WHERE id=?').get(intIn(ctx.params.id, 1, 1e9, 'Foto'));
    if (g) { db.prepare('DELETE FROM gallery WHERE id=?').run(+ctx.params.id); if (g.file.startsWith('/uploads/')) fs.rmSync(path.join(uploadsDir, path.basename(g.file)), { force: true }); }
    return { ok: true };
  });

  route('POST', '/api/admin/upload', A, (ctx) => {
    const m = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(ctx.body.data || ''));
    if (!m) throw bad('Envie uma imagem JPG, PNG ou WebP.');
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > 6 * 1024 * 1024) throw bad('Imagem muito grande (máx. 6 MB).');
    const isJpg = buf[0] === 0xff && buf[1] === 0xd8, isPng = buf.subarray(0, 4).toString('hex') === '89504e47', isWebp = buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP';
    const ext = isJpg ? 'jpg' : isPng ? 'png' : isWebp ? 'webp' : null;
    if (!ext) throw bad('Arquivo de imagem inválido.');
    const name = crypto.randomBytes(10).toString('hex') + '.' + ext;
    fs.writeFileSync(path.join(uploadsDir, name), buf);
    return { url: '/uploads/' + name };
  });

  // ---------- HTTP ----------
  const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
  const PAGES = { '/': 'index.html', '/agendar': 'agendar.html', '/painel': 'painel.html' };
  const SEC = {
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
  };

  function readBody(req, limit) {
    return new Promise((resolve, reject) => {
      const chunks = []; let n = 0;
      req.on('data', (c) => { n += c.length; if (n > limit) { reject(new HttpError(413, 'Requisição muito grande.')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => {
        if (!n) return resolve({});
        try { const j = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(j && typeof j === 'object' ? j : {}); } catch { reject(bad('JSON inválido.')); }
      });
      req.on('error', reject);
    });
  }

  function serveStatic(req, res, pathname) {
    let file;
    if (pathname.startsWith('/uploads/')) file = path.join(uploadsDir, path.basename(pathname));
    else file = path.join(publicDir, PAGES[pathname] || decodeURIComponent(pathname));
    const root = pathname.startsWith('/uploads/') ? uploadsDir : publicDir;
    if (!file.startsWith(root + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', ...SEC }); return res.end('Página não encontrada'); }
    const ext = path.extname(file).toLowerCase();
    const cache = /\.(png|jpg|jpeg|webp|svg|ico)$/.test(ext) ? 'public, max-age=604800' : 'no-cache';
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': cache, ...SEC });
    fs.createReadStream(file).pipe(res);
  }

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    const send = (status, obj, extra = {}) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...SEC, ...extra }); res.end(JSON.stringify(obj)); };
    try {
      if (!url.pathname.startsWith('/api/')) {
        if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Método não permitido.');
        return serveStatic(req, res, url.pathname);
      }
      let matched = null, params = {};
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const m = r.rx.exec(url.pathname);
        if (m) { matched = r; r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1]))); break; }
      }
      if (!matched) throw new HttpError(404, 'Rota não encontrada.');
      if (req.method !== 'GET') { // proteção CSRF: origem precisa ser a própria barbearia + corpo JSON
        const origin = req.headers.origin;
        if (origin && new URL(origin).host !== req.headers.host) throw new HttpError(403, 'Origem não permitida.');
        const ct = req.headers['content-type'] || '';
        if (matched.method !== 'DELETE' && !ct.includes('application/json') && Number(req.headers['content-length'] || 0) > 0) throw new HttpError(415, 'Use JSON.');
      }
      const ctx = { req, res, query: Object.fromEntries(url.searchParams), params, user: null, body: {} };
      if (matched.auth) {
        ctx.user = userFromReq(req);
        if (!ctx.user) throw new HttpError(401, 'Faça login para continuar.');
        if (matched.auth === 'admin' && ctx.user.role !== 'admin') throw new HttpError(403, 'Acesso restrito ao proprietário.');
      }
      if (req.method !== 'GET') ctx.body = await readBody(req, matched.rx.source.includes('upload') ? 9 * 1024 * 1024 : 100 * 1024);
      const result = matched.handler(ctx);
      if (ctx.raw) {
        res.writeHead(200, { 'Content-Type': ctx.raw.type, 'Content-Disposition': `attachment; filename="${ctx.raw.filename}"`, 'Cache-Control': 'no-store', ...SEC });
        return res.end(ctx.raw.body);
      }
      send(200, result, ctx.setCookie ? { 'Set-Cookie': ctx.setCookie } : {});
    } catch (e) {
      if (e instanceof HttpError) return send(e.status, { error: e.message });
      console.error(e); send(500, { error: 'Erro interno do servidor.' });
    }
  });

  return { server, db, slotsInfo };
}

module.exports = { createApp };

if (require.main === module) {
  const root = __dirname;
  const dataDir = process.env.DATA_DIR || path.join(root, 'data');
  const { server, db } = createApp({ dbFile: path.join(dataDir, 'amorim.db'), publicDir: path.join(root, 'public'), uploadsDir: path.join(dataDir, 'uploads') });
  const admin = DB.ensureAdmin(db);
  const port = process.env.PORT || 3000;
  server.listen(port, () => {
    console.log(`\n  Barbearia Amorim rodando em http://localhost:${port}`);
    console.log(`  Painel: http://localhost:${port}/painel`);
    if (admin) {
      console.log('\n  ── Acesso inicial do proprietário (anote agora) ──');
      console.log(`  Login: ${admin.username}`);
      console.log(`  Senha: ${admin.password}${admin.generated ? '   (gerada automaticamente — altere no painel)' : ''}\n`);
    }
  });
}
