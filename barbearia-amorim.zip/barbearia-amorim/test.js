'use strict';
// Testes automáticos de ponta a ponta: agendamento, logins, permissões, comissões e dashboards.
// Uso: node test.js
process.env.ADMIN_PASSWORD = 'senha-admin-123'; process.env.BOOK_LIMIT = '1000';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), assert = require('node:assert/strict');
const { createApp } = require('./server');
const DB = require('./db');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'amorim-'));
const { server, db } = createApp({ dbFile: path.join(tmp, 't.db'), publicDir: path.join(__dirname, 'public'), uploadsDir: path.join(tmp, 'up') });
DB.ensureAdmin(db);

let passed = 0;
const ok = (name) => { passed++; console.log('  ✔', name); };
const pad = (n) => String(n).padStart(2, '0');
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const dow = (s) => new Date(s + 'T00:00:00Z').getUTCDay();
const now = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo' }).format(new Date());

(async () => {
  await new Promise((r) => server.listen(0, r));
  const base = 'http://localhost:' + server.address().port;
  async function api(method, url, body, cookie) {
    const res = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const text = await res.text(); let json; try { json = JSON.parse(text); } catch { json = text; }
    const sc = res.headers.get('set-cookie');
    return { status: res.status, json, cookie: sc ? sc.split(';')[0] : null, headers: res.headers };
  }
  const login = async (u, p) => (await api('POST', '/api/auth/login', { username: u, password: p }));

  console.log('\nAutenticação');
  assert.equal((await login('admin', 'errada')).status, 401); ok('senha errada é recusada');
  const adm = await login('admin', 'senha-admin-123'); assert.equal(adm.status, 200); const A = adm.cookie; ok('login do proprietário');
  assert.equal((await api('GET', '/api/agenda?from=2026-01-01&to=2026-01-31')).status, 401); ok('agenda exige login');

  console.log('\nCadastro de barbeiros (painel do proprietário)');
  const c1 = await api('POST', '/api/admin/barbers', { name: 'Carlos Silva', username: 'carlos', password: 'carlos1234', bio: 'Especialista em fade', work_days: [1, 2, 3, 4, 5, 6] }, A);
  const c2 = await api('POST', '/api/admin/barbers', { name: 'João Pedro', username: 'joao', password: 'joao12345', work_days: [1, 2, 3, 4, 5] }, A);
  assert.equal(c1.status, 200); assert.equal(c2.status, 200);
  const B1 = c1.json.barber.id, B2 = c2.json.barber.id;
  assert.equal((await api('POST', '/api/admin/barbers', { name: 'Outro', username: 'CARLOS', password: '12345678' }, A)).status, 409); ok('login duplicado é recusado');
  assert.equal((await api('POST', '/api/admin/barbers', { name: 'Fraco', username: 'fraco', password: '123' }, A)).status, 400); ok('senha curta é recusada');
  const row = db.prepare('SELECT pass_hash FROM users WHERE id=?').get(B1);
  assert.ok(row.pass_hash.startsWith('scrypt$') && !row.pass_hash.includes('carlos1234')); ok('senhas são guardadas com hash (scrypt)');
  const cl = await login('carlos', 'carlos1234'), jo = await login('joao', 'joao12345');
  assert.equal(cl.status, 200); assert.equal(jo.status, 200); const C = cl.cookie, J = jo.cookie; ok('logins individuais dos barbeiros');

  console.log('\nÁrea pública não vaza dados privados');
  const info = (await api('GET', '/api/public/info')).json;
  assert.equal(info.barbers.length, 2);
  const dump = JSON.stringify(info);
  assert.ok(!/pass_hash|username|commission|carlos1234/i.test(dump)); ok('info pública sem login/senha/comissão');
  assert.equal(info.gallery.length, 8); ok('galeria carregada com as 8 fotos enviadas');
  for (const p of ['/api/stats', '/api/history', '/api/admin/barbers', '/api/admin/ranking']) assert.equal((await api('GET', p + '?from=2026-01-01&to=2026-12-31')).status, 401);
  ok('endpoints financeiros e administrativos não são públicos');

  console.log('\nAgendamento pelo cliente');
  let fut = addDays(now, 1); while (![1, 2, 3, 4, 5].includes(dow(fut))) fut = addDays(fut, 1);
  const svc = Object.fromEntries(info.services.map((s) => [s.name, s]));
  const slots1 = (await api('GET', `/api/public/slots?barber=${B1}&date=${fut}`)).json.slots;
  assert.ok(slots1.length >= 10); assert.equal(slots1[0].time, '09:00'); ok(`horários livres de ${fut} aparecem (${slots1.length})`);
  const book = (b, date, time, service, name = 'Cliente Teste', phone = '(11) 91234-5678') => api('POST', '/api/public/book', { barber_id: b, service_id: service.id, date, time, name, phone });
  const r1 = await book(B1, fut, '10:00', svc['Corte']); assert.equal(r1.status, 200); ok('agendamento confirmado');
  assert.equal((await book(B1, fut, '10:00', svc['Corte'], 'Outro Cliente')).status, 409); ok('mesmo horário com o mesmo barbeiro é bloqueado');
  const s1 = (await api('GET', `/api/public/slots?barber=${B1}&date=${fut}`)).json.slots.map((s) => s.time);
  const s2 = (await api('GET', `/api/public/slots?barber=${B2}&date=${fut}`)).json.slots.map((s) => s.time);
  assert.ok(!s1.includes('10:00') && s2.includes('10:00')); ok('horário ocupado some só da agenda daquele barbeiro');
  assert.equal((await book(B2, fut, '10:00', svc['Corte'], 'Cliente Dois')).status, 200); ok('outro barbeiro aceita o mesmo horário (sem conflito entre profissionais)');
  assert.equal((await book(B1, fut, '09:00', svc['Corte + Barba'])).status, 200);
  assert.equal((await book(B1, fut, '09:30', svc['Corte'])).status, 409); ok('serviço de 60 min ocupa dois horários (sem sobreposição)');
  assert.equal((await book(B1, fut, '09:30', svc['Corte + Barba'], 'Xa')).status, 409);
  assert.equal((await book(B1, fut, '19:00', svc['Corte'])).status, 409); ok('fora do expediente é bloqueado');
  assert.equal((await book(B1, fut, '10:15', svc['Corte'])).status, 409); ok('horário fora da grade é bloqueado');
  let sun = addDays(now, 1); while (dow(sun) !== 0) sun = addDays(sun, 1);
  assert.equal((await book(B1, sun, '10:00', svc['Corte'])).status, 409); ok('domingo (fechado) é bloqueado');
  let sat = addDays(now, 1); while (dow(sat) !== 6) sat = addDays(sat, 1);
  assert.equal((await book(B2, sat, '10:00', svc['Corte'])).status, 409); ok('dia de folga do barbeiro (B2 não trabalha sábado) é bloqueado');
  assert.equal((await book(B1, addDays(now, -1), '10:00', svc['Corte'])).status, 409); ok('data no passado é bloqueada');
  assert.equal((await book(B1, addDays(now, 200), '10:00', svc['Corte'])).status, 409); ok('além da antecedência máxima é bloqueado');
  assert.equal((await book(B1, fut, '11:00', svc['Corte'], 'A', '123')).status, 400); ok('telefone inválido é recusado');
  // corrida: várias requisições simultâneas no mesmo horário → apenas uma vence
  const race = await Promise.all(Array.from({ length: 8 }, (_, i) => book(B1, fut, '15:00', svc['Corte'], 'Corrida ' + i)));
  assert.equal(race.filter((r) => r.status === 200).length, 1); ok('8 requisições simultâneas no mesmo horário → só 1 confirmada');

  console.log('\nBloqueios');
  let fut2 = addDays(fut, 1); while (![1, 2, 3, 4, 5].includes(dow(fut2))) fut2 = addDays(fut2, 1);
  assert.equal((await api('POST', '/api/admin/blocks', { barber_id: B2, date: fut2, start: '14:00', end: '16:00', reason: 'Médico' }, A)).status, 200);
  const sb = (await api('GET', `/api/public/slots?barber=${B2}&date=${fut2}`)).json.slots.map((s) => s.time);
  assert.ok(!sb.includes('14:00') && !sb.includes('15:30') && sb.includes('16:00') && sb.includes('13:30')); ok('horário bloqueado não aparece');
  assert.equal((await book(B2, fut2, '14:30', svc['Corte'])).status, 409); ok('agendar em horário bloqueado é recusado');
  assert.equal((await book(B1, fut2, '14:30', svc['Corte'])).status, 200); ok('bloqueio de um barbeiro não afeta o outro');
  assert.equal((await api('POST', '/api/admin/blocks', { date: fut2, reason: 'Feriado' }, A)).status, 200);
  assert.equal((await api('GET', `/api/public/slots?barber=${B1}&date=${fut2}`)).json.slots.length, 0); ok('bloqueio do dia inteiro da barbearia zera os horários');

  console.log('\nAgenda de cada profissional e permissões');
  const ag1 = (await api('GET', `/api/agenda?from=${fut}&to=${fut}`, null, C)).json.appointments;
  const ag2 = (await api('GET', `/api/agenda?from=${fut}&to=${fut}`, null, J)).json.appointments;
  assert.ok(ag1.length === 3 && ag1.every((a) => a.barber_id === B1)); assert.ok(ag2.length === 1 && ag2[0].barber_id === B2);
  ok('agendamento aparece na agenda do barbeiro correto');
  const spy = (await api('GET', `/api/agenda?from=${fut}&to=${fut}&barber=${B2}`, null, C)).json.appointments;
  assert.ok(spy.every((a) => a.barber_id === B1)); ok('barbeiro não consegue ver a agenda de outro (mesmo forçando o parâmetro)');
  const adminAgenda = (await api('GET', `/api/agenda?from=${fut}&to=${fut}`, null, A)).json.appointments;
  assert.equal(adminAgenda.length, 4); ok('proprietário vê todas as agendas');
  for (const p of ['/api/admin/barbers', '/api/admin/settings', '/api/admin/ranking?from=2026-01-01&to=2026-12-31', '/api/admin/report?from=2026-01-01&to=2026-12-31', '/api/admin/report.csv?from=2026-01-01&to=2026-12-31']) assert.equal((await api('GET', p, null, C)).status, 403);
  assert.equal((await api('POST', '/api/admin/barbers', { name: 'Hack', username: 'hack', password: '12345678' }, C)).status, 403);
  assert.equal((await api('PUT', '/api/admin/settings', { shop_name: 'X' }, C)).status, 403); ok('barbeiro não acessa nenhuma rota administrativa');
  const apptB2 = ag2[0].id;
  assert.equal((await api('PATCH', `/api/appointments/${apptB2}/status`, { status: 'cancelado' }, C)).status, 404); ok('barbeiro não altera atendimento de outro');

  console.log('\nFaturamento e comissão de 50%');
  const cheio = await api('POST', '/api/admin/services', { name: 'Pacote Teste', price_cents: 20000, duration_min: 30 }, A);
  let past = addDays(now, -3); while (![1, 2, 3, 4, 5].includes(dow(past))) past = addDays(past, -1);
  const man = (b, time, sid, cookie, name = 'Balcão') => api('POST', '/api/appointments', { barber_id: b, service_id: sid, date: past, time, client_name: name, client_phone: '' }, cookie);
  const m1 = await man(B1, '09:00', cheio.json.id, C); assert.equal(m1.status, 200);
  const done = (id, cookie, method = 'pix') => api('PATCH', `/api/appointments/${id}/status`, { status: 'concluido', payment_method: method }, cookie);
  assert.equal((await api('PATCH', `/api/appointments/${m1.json.appointment.id}/status`, { status: 'concluido' }, C)).status, 400); ok('concluir exige forma de pagamento');
  const d1 = await done(m1.json.appointment.id, C); assert.equal(d1.status, 200);
  assert.equal(d1.json.appointment.commission_cents, 10000); assert.equal(d1.json.appointment.shop_cents, 10000);
  ok('R$ 200 de serviço → R$ 100 de comissão + R$ 100 da barbearia (exemplo do projeto)');
  await done(m1.json.appointment.id, C); await done(m1.json.appointment.id, C);
  let st = (await api('GET', `/api/stats?from=${past}&to=${past}`, null, C)).json;
  assert.equal(st.totals.gross, 20000); assert.equal(st.totals.count, 1); ok('concluir várias vezes não contabiliza em duplicidade');
  const m2 = await man(B1, '10:00', svc['Corte'].id, C); const m3 = await man(B1, '10:30', svc['Barba'].id, C); const m4 = await man(B1, '11:00', svc['Corte'].id, C);
  await api('PATCH', `/api/appointments/${m2.json.appointment.id}/status`, { status: 'cancelado' }, C);
  await api('PATCH', `/api/appointments/${m3.json.appointment.id}/status`, { status: 'faltou' }, C);
  st = (await api('GET', `/api/stats?from=${past}&to=${past}`, null, C)).json;
  assert.equal(st.totals.gross, 20000); assert.equal(st.by_status.cancelado, 1); assert.equal(st.by_status.faltou, 1); ok('cancelado e "não compareceu" não entram no faturamento');
  await done(m4.json.appointment.id, C, 'dinheiro'); // R$ 40
  const mb = await man(B2, '09:00', svc['Corte + Barba'].id, J); await done(mb.json.appointment.id, J, 'cartao_credito'); // R$ 65 → 32,50 / 32,50
  st = (await api('GET', `/api/stats?from=${past}&to=${past}`, null, C)).json;
  assert.equal(st.totals.gross, 24000); assert.equal(st.totals.commission, 12000); assert.equal(st.totals.shop, 12000); ok('totais do barbeiro 1: bruto 240 / comissão 120 / barbearia 120');
  const stJ = (await api('GET', `/api/stats?from=${past}&to=${past}`, null, J)).json;
  assert.equal(stJ.totals.gross, 6500); assert.equal(stJ.totals.commission, 3250); ok('barbeiro 2 vê apenas o próprio faturamento (65,00 / 32,50)');
  const stSpy = (await api('GET', `/api/stats?from=${past}&to=${past}&barber=${B2}`, null, C)).json;
  assert.equal(stSpy.totals.gross, 24000); ok('barbeiro não consegue consultar o faturamento de outro');
  const hSpy = (await api('GET', `/api/history?from=${past}&to=${past}&barber=${B2}`, null, C)).json;
  assert.ok(hSpy.rows.every((r) => r.barber_name === 'Carlos Silva') && hSpy.total === 2); ok('histórico também é isolado por barbeiro');
  const stA = (await api('GET', `/api/stats?from=${past}&to=${past}`, null, A)).json;
  assert.equal(stA.totals.gross, 30500); assert.equal(stA.totals.commission, 15250); assert.equal(stA.totals.shop, 15250); ok('proprietário vê o consolidado (305,00 = 152,50 + 152,50)');
  const rk = (await api('GET', `/api/admin/ranking?from=${past}&to=${past}`, null, A)).json.ranking;
  assert.equal(rk[0].name, 'Carlos Silva'); assert.equal(rk[0].gross, 24000); assert.equal(rk[1].gross, 6500); ok('ranking de rendimento ordenado');
  const mo = (await api('GET', `/api/stats/months?year=${past.slice(0, 4)}`, null, C)).json.months.find((m) => m.month === past.slice(0, 7));
  assert.equal(mo.gross, 24000); ok('comparativo mensal reflete os lançamentos');
  assert.equal((await api('PATCH', `/api/appointments/${m1.json.appointment.id}/status`, { status: 'cancelado' }, C)).status, 403); ok('barbeiro não consegue reabrir/cancelar atendimento já concluído');
  const futAppt = ag1[0].id;
  assert.equal((await done(futAppt, C)).status, 400); ok('não é possível concluir atendimento de data futura');
  const up = (await api('GET', `/api/stats?from=${past}&to=${past}`, null, C)).json.upcoming; assert.ok(up >= 3); ok(`agendamentos futuros contados (${up})`);
  assert.equal((await api('PATCH', `/api/appointments/${m1.json.appointment.id}/status`, { status: 'agendado' }, A)).status, 200);
  st = (await api('GET', `/api/stats?from=${past}&to=${past}`, null, C)).json;
  assert.equal(st.totals.gross, 4000); ok('proprietário reabre atendimento → lançamento financeiro é estornado');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM transactions WHERE appointment_id=?').get(m1.json.appointment.id).n, 0);
  const csv = await api('GET', `/api/admin/report.csv?from=${past}&to=${past}&by=month`, null, A);
  assert.ok(typeof csv.json === 'string' && csv.json.includes('Carlos Silva')); ok('relatório CSV gerado');
  const rep = (await api('GET', `/api/admin/report?from=${past.slice(0, 4)}-01-01&to=${past.slice(0, 4)}-12-31&by=year`, null, A)).json;
  assert.equal(rep.totals.gross, 10500); ok('relatório anual consistente');

  console.log('\nConta e sessão');
  assert.equal((await api('POST', '/api/auth/password', { current: 'carlos1234', new: 'novasenha99' }, C)).status, 200);
  assert.equal((await login('carlos', 'carlos1234')).status, 401); assert.equal((await login('carlos', 'novasenha99')).status, 200); ok('troca de senha');
  await api('PUT', `/api/admin/barbers/${B2}`, { ...c2.json.barber, active: false }, A);
  assert.equal((await api('GET', '/api/auth/me', null, J)).json.user, null); ok('barbeiro desativado perde o acesso imediatamente');
  assert.equal((await api('GET', '/api/public/info')).json.barbers.length, 1); ok('barbeiro desativado some do agendamento');
  await api('POST', '/api/auth/logout', {}, C); assert.equal((await api('GET', '/api/auth/me', null, C)).json.user, null); ok('logout encerra a sessão');
  let last; for (let i = 0; i < 10; i++) last = await login('admin', 'x' + i); assert.equal(last.status, 429); ok('bloqueio após muitas tentativas de login');
  const csrf = await fetch(base + '/api/admin/services', { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'https://evil.example', Cookie: A }, body: '{}' });
  assert.equal(csrf.status, 403); ok('requisição de origem externa é recusada (CSRF)');

  console.log(`\n${passed} verificações passaram ✔\n`);
  server.close(); fs.rmSync(tmp, { recursive: true, force: true }); process.exit(0);
})().catch((e) => { console.error('\n✘ FALHOU:', e); server.close(); process.exit(1); });
