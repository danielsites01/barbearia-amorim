'use strict';
// Banco de dados SQLite (módulo nativo do Node 22+, sem dependências externas)
const { DatabaseSync } = require('node:sqlite');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(pw, salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}
function verifyPassword(pw, stored) {
  try {
    const [, saltHex, hashHex] = stored.split('$');
    const expected = Buffer.from(hashHex, 'hex');
    const got = crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), expected.length);
    return crypto.timingSafeEqual(expected, got);
  } catch { return false; }
}

const DEFAULT_HOURS = {
  0: null,
  1: ['09:00', '19:00'], 2: ['09:00', '19:00'], 3: ['09:00', '19:00'],
  4: ['09:00', '19:00'], 5: ['09:00', '19:00'], 6: ['09:00', '17:00'],
};

const DEFAULT_SETTINGS = {
  shop_name: 'Barbearia Amorim',
  tagline: 'Tradição, estilo e precisão em cada corte.',
  about: 'Na Barbearia Amorim, cada cliente é atendido com atenção aos detalhes. Nossos barbeiros dominam as principais técnicas — do degradê navalhado ao corte na tesoura — para entregar um visual alinhado ao seu estilo, em um ambiente descontraído e profissional.',
  address: '', phone: '', whatsapp: '', instagram: '', maps_url: '',
  slot_minutes: '30', advance_days: '30', min_lead_minutes: '15',
  timezone: 'America/Sao_Paulo',
  hours: JSON.stringify(DEFAULT_HOURS),
};

const DEFAULT_SERVICES = [
  ['Corte', 4000, 30], ['Barba', 3000, 30], ['Corte + Barba', 6500, 60],
  ['Corte Infantil', 3500, 30], ['Sobrancelha', 1500, 30], ['Pigmentação', 3000, 30],
];

const CATEGORIES = [
  ['mid-fade', 'Mid Fade'], ['low-fade', 'Low Fade'], ['high-fade', 'High Fade'],
  ['degrade-navalhado', 'Degradê Navalhado'], ['social', 'Corte Social'],
  ['americano', 'Corte Americano'], ['infantil', 'Corte Infantil'],
  ['tesoura', 'Corte na Tesoura'], ['outros', 'Outros modelos'],
];

const GALLERY_SEED = [
  ['mid-fade', 'mid-fade-1.jpg', 'Mid Fade'], ['mid-fade', 'mid-fade-2.jpg', 'Mid Fade'],
  ['low-fade', 'low-fade-1.jpg', 'Low Fade'], ['low-fade', 'low-fade-2.jpg', 'Low Fade'],
  ['high-fade', 'high-fade-1.jpg', 'High Fade'], ['high-fade', 'high-fade-2.jpg', 'High Fade'],
  ['americano', 'americano-1.jpg', 'Americano'], ['tesoura', 'tesoura-1.jpg', 'Corte na tesoura'],
];

function open(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    pass_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin','barber')),
    bio TEXT NOT NULL DEFAULT '',
    photo TEXT NOT NULL DEFAULT '',
    work_days TEXT NOT NULL DEFAULT '[1,2,3,4,5,6]',
    commission_pct INTEGER NOT NULL DEFAULT 50 CHECK (commission_pct BETWEEN 0 AND 100),
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
    duration_min INTEGER NOT NULL DEFAULT 30 CHECK (duration_min > 0),
    active INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    barber_id INTEGER NOT NULL REFERENCES users(id),
    service_id INTEGER REFERENCES services(id),
    service_name TEXT NOT NULL,
    price_cents INTEGER NOT NULL,
    client_name TEXT NOT NULL,
    client_phone TEXT NOT NULL,
    date TEXT NOT NULL,
    start_min INTEGER NOT NULL,
    end_min INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'agendado' CHECK (status IN ('agendado','concluido','cancelado','faltou')),
    source TEXT NOT NULL DEFAULT 'site',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_appt_barber_date ON appointments(barber_id, date);
  -- Garantia extra no banco: mesmo barbeiro, mesmo dia e mesmo horário de início só uma vez (ativos)
  CREATE UNIQUE INDEX IF NOT EXISTS uq_appt_slot ON appointments(barber_id, date, start_min)
    WHERE status IN ('agendado','concluido');
  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    appointment_id INTEGER NOT NULL UNIQUE REFERENCES appointments(id),
    barber_id INTEGER NOT NULL REFERENCES users(id),
    date TEXT NOT NULL,
    gross_cents INTEGER NOT NULL,
    commission_pct INTEGER NOT NULL,
    commission_cents INTEGER NOT NULL,
    shop_cents INTEGER NOT NULL,
    payment_method TEXT NOT NULL,
    paid_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_tx_barber_date ON transactions(barber_id, date);
  CREATE TABLE IF NOT EXISTS blocks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    barber_id INTEGER REFERENCES users(id) ON DELETE CASCADE, -- NULL = toda a barbearia
    date TEXT NOT NULL,
    start_min INTEGER,  -- NULL = dia inteiro
    end_min INTEGER,
    reason TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS categories (slug TEXT PRIMARY KEY, name TEXT NOT NULL, sort INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS gallery (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL REFERENCES categories(slug),
    file TEXT NOT NULL,
    caption TEXT NOT NULL DEFAULT '',
    sort INTEGER NOT NULL DEFAULT 0
  );
  `);

  // Seeds (apenas na primeira execução)
  const ins = db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)');
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) ins.run(k, v);
  if (db.prepare('SELECT COUNT(*) c FROM categories').get().c === 0) {
    const c = db.prepare('INSERT INTO categories(slug,name,sort) VALUES (?,?,?)');
    CATEGORIES.forEach(([s, n], i) => c.run(s, n, i));
  }
  if (db.prepare('SELECT COUNT(*) c FROM services').get().c === 0) {
    const s = db.prepare('INSERT INTO services(name,price_cents,duration_min) VALUES (?,?,?)');
    DEFAULT_SERVICES.forEach(r => s.run(...r));
  }
  if (db.prepare('SELECT COUNT(*) c FROM gallery').get().c === 0) {
    const g = db.prepare('INSERT INTO gallery(category,file,caption,sort) VALUES (?,?,?,?)');
    GALLERY_SEED.forEach(([cat, f, cap], i) => g.run(cat, '/img/gallery/' + f, cap, i));
  }
  return db;
}

// Cria o administrador inicial se não existir nenhum. Retorna a senha gerada (ou null).
function ensureAdmin(db) {
  if (db.prepare("SELECT COUNT(*) c FROM users WHERE role='admin'").get().c > 0) return null;
  const username = process.env.ADMIN_USER || 'admin';
  const generated = !process.env.ADMIN_PASSWORD;
  const password = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
  db.prepare("INSERT INTO users(name,username,pass_hash,role,work_days) VALUES (?,?,?,'admin','[]')")
    .run('Proprietário', username, hashPassword(password));
  return { username, password, generated };
}

module.exports = { open, ensureAdmin, hashPassword, verifyPassword, DEFAULT_HOURS };
