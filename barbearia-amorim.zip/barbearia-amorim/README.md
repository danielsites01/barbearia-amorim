# Barbearia Amorim — site e sistema de gestão

Site público (vitrine, galeria, agendamento online) + painel privado para barbeiros e proprietário.
Sem dependências externas: só precisa do **Node.js 22.13 ou superior**.

## Como rodar

```bash
npm start                       # http://localhost:3000
```

Na primeira execução o sistema cria o banco (`data/amorim.db`) e **mostra no terminal o login e a senha do proprietário**
(login `admin`). Para definir você mesmo: `ADMIN_USER=meulogin ADMIN_PASSWORD=minhasenha npm start`.
Troque a senha em **Painel → Dados**.

Para ver tudo preenchido com dados fictícios (barbeiros, atendimentos, faturamento):

```bash
DATA_DIR=./data-demo node demo.js && DATA_DIR=./data-demo npm start
# proprietário: admin / admin12345 — barbeiros: carlos, rafael, diego / demo12345
```

Testes automáticos (agendamento, conflitos, permissões, comissão de 50%, relatórios): `npm test`

## Primeiros passos no painel (/painel)

1. **Dados** — endereço, WhatsApp, Instagram, telefone e link do Google Maps (aparecem no site).
2. **Barbeiros** — cadastre cada profissional (login, senha, foto, apresentação, dias de trabalho).
3. **Serviços** — ajuste nomes, preços e durações (os valores iniciais são exemplos).
4. **Horários** — expediente por dia da semana, intervalo da agenda e bloqueios (folgas/feriados).
5. **Galeria** — envie novas fotos por categoria.

## Colocar no ar

Precisa de hospedagem que rode Node.js **com disco persistente** (o banco é um arquivo SQLite).
Ex.: Render, Railway, Fly.io ou uma VPS. Configure:

- Comando de início: `npm start` (Node 22.13+)
- `PORT` (a hospedagem normalmente define)
- `DATA_DIR` apontando para o disco persistente (guarda `amorim.db` e as fotos enviadas) — **faça backup dessa pasta**
- `TRUST_PROXY=1` e HTTPS ativado (o cookie de login vira `Secure` automaticamente atrás de HTTPS)
- Domínio próprio: aponte o DNS para a hospedagem

## Regras do sistema

- Comissão padrão de 50% (editável por barbeiro). Ao **concluir** um atendimento com a forma de pagamento,
  grava-se um lançamento financeiro único (bruto, comissão, parte da barbearia). Concluir de novo não duplica.
- Cancelado / não compareceu / agendado não entram no faturamento.
- Só o proprietário reabre um atendimento concluído (o lançamento é estornado).
- Barbeiro só enxerga a própria agenda e os próprios números; rotas administrativas exigem perfil de proprietário.
- Senhas com hash scrypt, sessão em cookie HttpOnly/SameSite, limite de tentativas de login e de agendamentos por IP.
